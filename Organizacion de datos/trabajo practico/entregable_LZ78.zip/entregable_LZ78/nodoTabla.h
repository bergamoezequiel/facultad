#ifndef NODOTABLA_H_INCLUDED
#define NODOTABLA_H_INCLUDED
#include <iostream>
#include<math.h>
#include "lista.h"
class nodoTabla
{
private:
    std::string caracteres;
    long int frecuencia; //por si aparece muchas veces, 1 por default
public:
    /* 2 caracteres, porque va de 9 a 14 bits*/
    unsigned char repBinaria[2];
    nodoTabla();
    /*crea el nodo tabla con caracteres iniciales*/
    void setNodoTabla(std::string aAgregar,char primerCaracterRepBi,char segundoCaracterRepBina);
    ~nodoTabla();
    /*Muestra los caracteres del nodo*/
    void mostrarCaracteres();
    /*modifica los caracteres del nodo*/
    void cambiarCaracteres(std::string aCambiar);
    /*compara la lista del nodo con la que se le pasa por paramero, si es identica devuelve true*/
    bool contiene(std::string lista);
    /*Devuelve true si la representacion binaria es la de los bits en la longitud indicada*/
    bool tieneRepBinaria(unsigned char primer,unsigned char segundo, int cantidadAComparar);
    bool tieneMenorRepresentacionBinariaQue(unsigned char repBina0,unsigned char repBina1,int cantidadDeBitsAComprar);
    std::string getListaCaracteres();
    void setFrecuencia(int valor);
    void incrementarFrecuencia();
    long int getFrecuencia();





};


#endif // NODOTABLA_H_INCLUDED

