/*
 * Tabla.cpp
 *
 *  Created on: 08/06/2014
 *      Author: alumno
 */

#include "Tabla.h"
//#include "lista.h"
//#include "nodoTabla.h"
#include <sstream>
#include <stdio.h>


using namespace std;

Tabla::Tabla()
{
    comprime=1;
    codigoProximoElemento[0]=0;
    codigoProximoElemento[1]=0;
    cantElementos=0;
    listaDeNodos= new nodoTabla[CANTIDAD_MAXIMA_DE_ELEMENTOS];
    for(int i=0; i<256; i++)
    {
        char caracter=i;
        string listaDeNodo = "";
        listaDeNodo += caracter;
        listaDeNodos[i].setNodoTabla(listaDeNodo,codigoProximoElemento[0],codigoProximoElemento[1]);
        mapParaBusquedaPorClave[listaDeNodo]=listaDeNodos+i;
        this->incrementarCodigoProximoElemento();
        cantElementos++;
    }
    /* Se crean y se agregan a la lista, todos los nodos restantes, no iniciales*/
    for(int i=CANTIDAD_INICIAL_DE_ELEMENTOS; i<CANTIDAD_MAXIMA_DE_ELEMENTOS; i++)
    {
        string caracteresAAgregar= "";
        listaDeNodos[i].setNodoTabla(caracteresAAgregar,codigoProximoElemento[0],codigoProximoElemento[1]);
        this->incrementarCodigoProximoElemento();
        //no incrementa cantidad de elementos porque no hay elementos, esto es para que queden inicializados todos los nodos
    }
}
// ESTO HAY QUE reveerlo
Tabla::~Tabla()
{
    delete[] listaDeNodos;
}

void Tabla::incrementarCodigoProximoElemento()
{
    if( codigoProximoElemento[1]<255)
        codigoProximoElemento[1]= codigoProximoElemento[1]+1;
    else
    {
        codigoProximoElemento[1]=0;
        codigoProximoElemento[0]=codigoProximoElemento[0]+1;
    }
}

bool Tabla::estaLlena()
{
    return (cantElementos==CANTIDAD_MAXIMA_DE_ELEMENTOS);
}

bool Tabla::estaLlenaDesc()
{
    return (cantElementos==CANTIDAD_MAXIMA_DE_ELEMENTOS-1);
}

nodoTabla* Tabla::agregar(string caracteresAAgregar)
{
    if (!estaLlena())
    {
        int posicion= cantElementos;
        listaDeNodos[posicion].cambiarCaracteres(caracteresAAgregar);
        listaDeNodos[posicion].setFrecuencia(1);
        mapParaBusquedaPorClave[caracteresAAgregar]=listaDeNodos+posicion;
        cantElementos++;
        return &listaDeNodos[posicion];
    }
    else
    {
        //rescato el ultimo nodo
        cantElementos--;
        int posicion= cantElementos;
        string caracteresSalvados= listaDeNodos[posicion].getListaCaracteres();
        int frecuenciaSalvada= listaDeNodos[posicion].getFrecuencia();
        listaDeNodos[posicion].cambiarCaracteres("");
        listaDeNodos[posicion].setFrecuencia(0);

        this->limpiarTabla();
        cantElementos= CANTIDAD_MAXIMA_DE_ELEMENTOS - CANTIDAD_DE_ELEMENTOS_A_BORRAR-1;
        posicion= cantElementos;
        listaDeNodos[posicion].cambiarCaracteres(caracteresSalvados);
        listaDeNodos[posicion].setFrecuencia(frecuenciaSalvada);
        cantElementos++;

        this->agregar(caracteresAAgregar);
        mapParaBusquedaPorClave.clear();
        for(int i=0; i<cantElementos; i++)
        {
            string caracter=listaDeNodos[i].getListaCaracteres();
            mapParaBusquedaPorClave[caracter]=listaDeNodos+i;
        }
        return NULL;
    }
}


void Tabla::limpiarTabla()
{
    LimpiadorDeTabla* limpiador= new LimpiadorDeTabla(listaDeNodos,cantElementos);
    delete limpiador;
}


void Tabla::limpiezaDesc()
{
    this->limpiarTabla();
    cantElementos= CANTIDAD_MAXIMA_DE_ELEMENTOS - CANTIDAD_DE_ELEMENTOS_A_BORRAR -1;
}


/*muestra solo los caracteres almacenados en cada nodo, junto con su representacion binaria*/
void Tabla::mostrarTabla()
{
    for(int i=250; i<cantElementos; i++)
    {
        listaDeNodos[i].mostrarCaracteres();
    }
}

int Tabla::getCantidadDeElementos()
{
    return cantElementos;
}

bool Tabla::estaLaClave(string caracteresAComp)
{
    std::map<string,nodoTabla*>::iterator it;
    std::map<string,nodoTabla*>::iterator it2;
    it=mapParaBusquedaPorClave.find(caracteresAComp);
    it2=mapParaBusquedaPorClave.end();
    return not (it==it2);
}

bool Tabla::estaLaRep(char repBina0,char repBina1, int cantidadDeBitsAComprar)
{
    int primero=0;
    int ultimo=cantElementos-1;
    bool encontrado=false;
    int i=1;
    while ((primero<=ultimo) && (not encontrado))
    {
        i++;
        int central= primero + ((ultimo-primero)/2);
        if (listaDeNodos[central].tieneRepBinaria(repBina0,repBina1,cantidadDeBitsAComprar))
            encontrado=true;
        else if (listaDeNodos[central].tieneMenorRepresentacionBinariaQue(repBina0,repBina1,cantidadDeBitsAComprar))
            primero=central+1;
        else
            ultimo=central-1;
    }
    return encontrado;
}

nodoTabla* Tabla::devolverNodoConClave(string caracteresAComp)
{
    return mapParaBusquedaPorClave[caracteresAComp];
}

nodoTabla* Tabla::devolverNodoConRepBinaria(char repBina0,char repBina1, int cantidadDeBitsAComprar)
{
    int primero=0;
    int ultimo=cantElementos-1;
    bool encontrado=false;
    int central;
    int i=1;
    while ((primero<=ultimo) && (not encontrado))
    {
        i++;
        central= primero + ((ultimo-primero)/2);
        if (listaDeNodos[central].tieneRepBinaria(repBina0,repBina1,cantidadDeBitsAComprar))
            encontrado=true;
        else if (listaDeNodos[central].tieneMenorRepresentacionBinariaQue(repBina0,repBina1,cantidadDeBitsAComprar))
            primero=central+1;
        else
            ultimo=central-1;
    }
    return listaDeNodos + central;
}
