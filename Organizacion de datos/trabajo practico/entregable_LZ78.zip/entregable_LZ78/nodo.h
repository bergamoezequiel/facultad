#ifndef NODO_H
#define NODO_H

#include <iostream>

template <class Dato>
class Nodo
{
private:
    /* dato almacenado en el nodo */
    Dato dato;
    /* puntero al siguiente nodo en la lista */
    Nodo<Dato>* siguiente;

public:
    /*
     * pre: el tipo de dato debe ser el mismo que en los
     *      demás nodos
     * post: inicializa una instancia Nodo con el dato
     *       especificado
     */
    Nodo(Dato dato);

    ~Nodo();

    /*
     * pre: el tipo de dato debe ser el mismo que en los
     *      demás nodos
     * post: asigna el dato especificado al nodo
     */
    void setDato(Dato nuevoDato);

    /*
     * post: asigna el siguiente nodo de la lista
     */
    void setSiguiente(Nodo<Dato>* otroNodo);

    /*
     * post: devuelve el dato del nodo
     */
    Dato getDato();

    /*
     * post: devuelve un puntero al siguiente nodo de la
     *       lista
     */
    Nodo* getSiguiente();
};

template <class Dato>
Nodo<Dato>::Nodo(Dato dato)
{
    this->setDato(dato);
    this->setSiguiente(NULL);
}

template <class Dato>
void Nodo<Dato>::setDato(Dato nuevoDato)
{
    this->dato = nuevoDato;
}

template <class Dato>
void Nodo<Dato>::setSiguiente(Nodo<Dato>* otroNodo)
{
    this->siguiente = otroNodo;
}

template <class Dato>
Dato Nodo<Dato>::getDato()
{
    return this->dato;
}

template <class Dato>
Nodo<Dato>* Nodo<Dato>::getSiguiente()
{
    return this->siguiente;
}


template <class Dato>
Nodo<Dato>::~Nodo()
{
}

#endif
