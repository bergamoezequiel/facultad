/*
 * LZW.cpp
 *
 *  Created on: 08/06/2014
 *      Author: alumno
 */

#include "LZW.h"
#include "lista.h"
#include "nodoTabla.h"
#include "BufferBinario.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
namespace LZW
{

void convertirBinarioAChar(char &repBinariaUno, char &repBinariaDos, unsigned int binario)
{
    std::string codigo = "";
    std::string codUno;
    std::string codDos;

    do
    {
        if ((binario & 1) == 0)
        {
            codigo += "0";
        }
        else
        {
            codigo += "1";
        }
        binario >>= 1;
    }
    while (binario);


    while(codigo.length() < 16)
    {
        codigo += "0";
    }

    codigo = std::string(codigo.rbegin(), codigo.rend());
    codUno = codigo.substr(8, 16);
    codDos = codigo.substr(0, 8);
    repBinariaUno = strtol(codUno.c_str(), 0, 2);
    repBinariaDos = strtol(codDos.c_str(), 0, 2);
}




///----------------------------------------------------------------------------------------


//void descomprimir(char* entrada, char* salida, Tabla &tabla)
void descomprimir(char* entrada, char* salida, Tabla &tabla, BufferBinario &buffer)
{
    int cantBits = 9;
    std::string caracter = "";
    std::string caracterAnt = "";
    std::string caracterAAgregar = "";
    char repBinariaUno;
    char repBinariaDos;
    nodoTabla* codigo;
    //BufferBinario buffer;
    bool esPrimeraVez= true;

    std::ofstream fsalida(salida, std::ios::out | std::ios::binary);

    buffer.leerDesdeArchivoBufferCompleto(entrada);

    // Mientras haya algo en el buffer
    while(buffer.quedanClavesPorLeer(cantBits))
    {
        // Se lee la clave de la cantidad de bits que se esté usando
        unsigned int clave = buffer.obtenerNumClave(cantBits);


        // Se convierte a chars para la representación binaria de la Tabla
        if (clave >= 256)
        {
            convertirBinarioAChar(repBinariaUno, repBinariaDos, clave);
        }
        else
        {
            repBinariaUno = (char)clave;
            repBinariaDos = (char)0;
        }


        // Se busca la representación en la Tabla para conseguir el caracter
        if (esPrimeraVez)
        {
            codigo=tabla.devolverNodoConRepBinaria(repBinariaDos,repBinariaUno,cantBits);
            caracter=codigo->getListaCaracteres();
            esPrimeraVez=false;
        }
        else
        {
            if(tabla.estaLaRep(repBinariaDos,repBinariaUno,cantBits))
            {
                codigo=tabla.devolverNodoConRepBinaria(repBinariaDos,repBinariaUno,cantBits);
                caracter=codigo->getListaCaracteres();
                caracterAAgregar=caracterAnt+caracter[0];
                if (tabla.estaLlenaDesc())
                    tabla.limpiezaDesc();
                tabla.agregar(caracterAAgregar);

            }
            else
            {
                caracterAAgregar=caracterAnt+caracterAnt[0];
                if (tabla.estaLlenaDesc())
                    tabla.limpiezaDesc();
                tabla.agregar(caracterAAgregar);

                nodoTabla* nodo=tabla.devolverNodoConClave(caracterAAgregar);
                //  nodo->incrementarFrecuencia();
                codigo=tabla.devolverNodoConRepBinaria(repBinariaDos,repBinariaUno,cantBits);
                caracter=codigo->getListaCaracteres();

            }

        }
        // el menos uno es porque al compresor se le llenó la tabla un paso antes que al descompresor
        // y ya empezó a emitir claves con 1 bit más
        if (tabla.getCantidadDeElementos() >= pow((int)2, cantBits)-1)
        {
            cantBits++;
            cout << endl << endl << ">>>>>>>>>>>>>>>>>>>><Aumento cantidad de bits<<<<<<<<<<<<<<<<<<<<<<<<<<" << endl << endl;
        }

        if (buffer.quedanClavesPorLeer(cantBits))
        {
            caracterAnt = caracter;
        }

        //codigo->incrementarFrecuencia();
        fsalida.write(caracter.c_str(), caracter.length());
    }
    fsalida.close();
}




///----------------------------------------------------------------------------------------



//void comprimir(std::ifstream &entrada, char* salida, Tabla &tabla)
void comprimir(std::ifstream &entrada, char* salida, Tabla &tabla, BufferBinario &buffer)
{

    char input;
    int cantBits = 9;
    nodoTabla* codigo;
    //BufferBinario buffer;

    // Hasta que se termine el archivo
    while (!entrada.eof())
    {
        std::string caracteres = "";

        // Lee el primer caracter del archivo
        entrada.get(input);

        // Lo agrega al listado de caracteres
        caracteres += input;

        // Mientras se encuentre un string con los caracteres leídos
        while((tabla.estaLaClave(caracteres))&&(!entrada.eof()))
        {
            // Buscar el nodo correspondiente en la tabla
            codigo = tabla.devolverNodoConClave(caracteres);

            // Buscar el siguiente caracter del archivo
            entrada.get(input);

            // Concatenarlo al string leído hasta el momento
            caracteres += input;
        }

        if ((entrada.eof()) && (tabla.estaLaClave(caracteres)))
        {
            //codigo=tabla.devolverNodoConClave(caracteres);
        }
        else      // Decrementa la posición actual del stream para que pueda leer de nuevo el último char leído
            if (!(entrada.eof()))
            {
                entrada.putback(input);
            }

        // Carga el código binario como un unsigned int: se suma el primer unsigned
        // char y el segundo * 256 (ya que el segundo char representa a los bits
        // de 256 en adelante)
        unsigned int repBinariaInt = 256*codigo->repBinaria[0] + codigo->repBinaria[1];

        // Se carga el código binario en el buffer temporal
        buffer.agregarClaveAlBuffer(repBinariaInt, cantBits);

        // Agregar el string encontrado más largo + el próximo caracter leído
        // a la tabla
        if (!tabla.estaLaClave(caracteres)&&(!entrada.eof()))
        {
            tabla.agregar(caracteres);
        }

        //codigo->incrementarFrecuencia();

        // Si se alcanzó el máximo posible de bits representables con la
        // cantidad de bits que se usan, incrementar la cantidad de bits
        // que se emiten por caracter
        if (tabla.getCantidadDeElementos() >= pow((int)2, cantBits))
        {
            cantBits++;
            cout << endl << endl << ">>>>>>>>>>>>>>>>>>>><Aumento cantidad de bits<<<<<<<<<<<<<<<<<<<<<<<<<<" << endl << endl;
        }
    }

    // Se escribe el buffer en el archivo
    //cout<<"cantidad de elementos en la tabla: "<<tabla.getCantidadDeElementos();

    buffer.guardarEnArchivoBufferCompleto(salida);
}


}
