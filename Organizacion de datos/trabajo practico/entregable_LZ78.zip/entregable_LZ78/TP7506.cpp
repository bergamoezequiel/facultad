//============================================================================
// Name        : TP7506.cpp
// Author      : BL
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <iostream>
#include <stdlib.h>
#include <string>
#include <fstream>
#include <queue>
#include <cstdio>
//#include "ArbolHuffman.h"
#include <sstream>
#include "LZW.h"
#include <stdio.h>
#define EXT_GRUPO ".14";

using namespace std;

ifstream archLectura;
ofstream archEscritura;

enum Operacion { Comprimir, Descomprimir, NoAparece, Desconocida };

bool checkearArchivoLectura(char* dir)
{
	if(dir)
	{
		string nombreArchivo(dir);
		archLectura.open(dir);
		if (archLectura.is_open())
		{
			cout << "Se pudo abrir el archivo " << nombreArchivo << endl;
			return true;
		}
		else
		{
			cout << "No se pudo abrir el archivo " << nombreArchivo << endl;
			return false;
		}
	}
	else
	{
		cout << "No se ingresó un archivo" << endl;
		return false;
	}
}

bool abrirArchivoEscritura(string nombreArchivoSalida)
{
	archEscritura.open(nombreArchivoSalida.c_str());
	return archEscritura.is_open();
}

Operacion leerComando(char* cmd)
{
	if (cmd)
	{
		string comando(cmd);
		if (comando == "-c")
		{
			cout << "Se pide comprimir" << endl;
			return Comprimir;
		}
		else if (comando == "-d")
		{
			cout << "Se pide descomprimir" << endl;
			return Descomprimir;
		}
		else
		{
			cout << "Operación no soportada" << endl;
			return Desconocida;
		}
	}
	else
	{
		cout << "Ingrese una operación" << endl;
		return NoAparece;
	}
}

void comprimir(char *nombreArchivoEntrada)
{
	string nombreArchivoSalida(nombreArchivoEntrada);
	string salidaStr = "salida";
	nombreArchivoSalida = nombreArchivoSalida + EXT_GRUPO;
	nombreArchivoSalida.replace(2, 7, salidaStr);
	char* archS = (char*)nombreArchivoSalida.c_str();
	cout << "Se intenta crear archivo " << nombreArchivoSalida << endl;

	if (abrirArchivoEscritura(nombreArchivoSalida))
	{
		cout << "Se creo el archivo " << nombreArchivoSalida << " exitosamente" << endl;
		cout << "Se ejecuta la opción de comprimir con archivo de salida " << nombreArchivoSalida << endl;
		cout << "Comprimiendo..." << endl;

		Tabla tabla;
		//char* salida = "./salidas/DespertarHombre.txt.z14";
		BufferBinario buffer;
		LZW::comprimir(archLectura, archS, tabla, buffer);
		//cout << "Fase LZW finalizada" << endl << "Comenzando compresión Huffman..." << endl;
		//escribirArchivoHuffman(archS, buffer, tabla);
		cout << "Compresión terminada." << endl;
	}
	else
	{
		cout << "No se pudo crear el archivo " << nombreArchivoSalida << endl;
		cout << "No se continúa con la compresión" << endl;
	}


}

void descomprimir(const char* nombreArchivoEntrada)
{
	string nombreArchivoSalida(nombreArchivoEntrada);
	nombreArchivoSalida.erase(nombreArchivoSalida.end()- 3, nombreArchivoSalida.end());

	cout << "Se intenta crear archivo " << nombreArchivoSalida << endl;

	if (abrirArchivoEscritura(nombreArchivoSalida))
	{
		cout << "Se creo el archivo " << nombreArchivoSalida << " exitosamente" << endl;
		cout << "Se ejecuta la opción de descomprimir con archivo de salida " << nombreArchivoSalida << endl;
		cout << "Descomprimiendo..." << endl;

		Tabla tabla;
		char* salida = (char*)nombreArchivoSalida.c_str();
		char* entrada = (char *)nombreArchivoEntrada;//"./salidas/DespertarHombre.txt.14";
		BufferBinario buffer;
		//leerArchivoHuffman(entrada, buffer);
		//cout << "Descompresión Huffman terminada" << endl << "Comienza descompresión LZW..." << endl;
		LZW::descomprimir(entrada, salida, tabla, buffer);

		cout << "Descompresión terminada." << endl;
	}
	else
	{
		cout << "No se pudo crear el archivo " << nombreArchivoSalida << endl;
		cout << "No se continúa con la descompresión" << endl;
	}


}

void leerLineaDeComando(const int &argc, char* argv[])
{
	// Supone que argv[0] es el nombre del programa

	// Se checkea que se haya pasado el parámetro de operación (-c o -d)
	Operacion operacion = leerComando(argv[1]);
	if (operacion != NoAparece && operacion != Desconocida)
	{
		bool seAbrioArchivoLectura = checkearArchivoLectura(argv[2]);
		if (operacion == Comprimir && seAbrioArchivoLectura)
		{
			comprimir(argv[2]);
		}
		else if (operacion == Descomprimir && seAbrioArchivoLectura)
		{
			descomprimir(argv[2]);
		}
	}
	archEscritura.close();
	archLectura.close();
}

int main(int argc, char* argv[]) {
//int main() {
	//int argc = 3;

	//char* argv[] = { "Prog", "-c", "./entradas/progl" };
	//char* argv[] = { "Prog", "-d", "./salidas/progl.14" };
	leerLineaDeComando(argc, argv);

	getchar();
	return 0;
}
