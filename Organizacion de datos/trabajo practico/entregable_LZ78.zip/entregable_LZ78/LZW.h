/*
 * LZW.h
 *
 *  Created on: 08/06/2014
 *      Author: alumno
 */

#ifndef LZW_H_
#define LZW_H_

#include <fstream>
#include "Tabla.h"
#include "BufferBinario.h"

namespace LZW
{
//void descomprimir(char* entrada, char* salida, Tabla &tabla);
//void comprimir(std::ifstream& entrada, char* salida, Tabla &tabla);
void descomprimir(char* entrada, char* salida, Tabla &tabla, BufferBinario &buffer);
void comprimir(std::ifstream& entrada, char* salida, Tabla &tabla, BufferBinario &buffer);
};



#endif /* LZW_H_ */
