/*
 * LimpiadorDeTabla.h
 *
 *  Created on: 08/06/2014
 *      Author: alumno
 */

#ifndef LIMPIADORDETABLA_H_
#define LIMPIADORDETABLA_H_

const int CANTIDAD_DE_ELEMENTOS_A_BORRAR=250; //250
const int CANTIDAD_MAXIMA_DE_MAS_NUEVOS = 200;//cantidad de elementos mas frecuentes que voy a tener en cuenta 200
const int CANTIDAD_MAXIMA_DE_ELEMENTOS = 16300;  //16348

//#include "lista.h"
#include "nodoTabla.h"

class LimpiadorDeTabla
{

private:
    /*Todos los nodos a vaciar se setean con frecuencia 0 y una lista nula de caracteres*/
    void limpiarLista(Lista< nodoTabla* >* nodosAVaciar);
    /* Agrupa al final de la tabla los nodos sin uso*/
    void agruparTabla();
    nodoTabla* listaProvenienteDeTabla;
    Lista< nodoTabla* >* nodosAVaciar;
    int comienzoDeBusquedaParaElProximoNull;
    int comienzoDeBusquedaParaElProximoAUbicarseEnNull;
    nodoTabla* irAlProximoAUbicarseEnNull();
    nodoTabla* irAlProximoNull();
    int recalcularPosicionNodoMayorFrecuencia();

public:
    LimpiadorDeTabla(nodoTabla* listaDeNodos, int cantidadDeElementos);
};




#endif /* LIMPIADORDETABLA_H_ */
