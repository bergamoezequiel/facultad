#include "BufferBinario.h"
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <math.h>

using namespace std;

//Constructor
BufferBinario::BufferBinario()
{
    this->tamanioBufferEnBytes= sizeof(unsigned int);
    this->cantidadBitsMaximos= this->tamanioBufferEnBytes * 8;
    this->tamanioBloqueEnBytes= CANTIDADBUFFERSINTERNOS * this->tamanioBufferEnBytes;
    this->establecerValoresPorDefecto();
}

//Destructor
BufferBinario::~BufferBinario()
{
    this->vaciarBufferes();
}

void BufferBinario::establecerValoresPorDefecto()
{
    this->numeroBloqueActual= 0;
    this->numeroBufferActual= 0;
    this->numeroBufferDeLecturaActual= 0;
    this->posicionDeLecturaActual= 0;
    this->cantidadBitsDisponibles = this->cantidadBitsMaximos;
    this->numeroBloqueLecturaActual= 0;
    this->bufferBinario[0]= new unsigned int [CANTIDADBUFFERSINTERNOS];

    for(int x=0; x< CANTIDADBUFFERSINTERNOS; x++)
    {
        this->bufferBinario[0][x]= 0;
    }
}

void BufferBinario::reinicializarBuffer()
{
    this->vaciarBufferes();
    this->establecerValoresPorDefecto();
}

void BufferBinario::vaciarBufferes()
{

    unsigned int x=0;
    for (x=0; x <= this->numeroBloqueActual; x++)
    {
        delete [] this->bufferBinario[x];
        this->bufferBinario[x]= NULL;
    }

    this->numeroBloqueActual=0;
}

unsigned int BufferBinario::obtenerBuffer(unsigned int numeroBloque, unsigned int numeroBuffer)
{

    if ((numeroBloque < this->numeroBloqueActual) && (numeroBuffer < CANTIDADBUFFERSINTERNOS))
    {
        return this->bufferBinario[numeroBloque][numeroBuffer];
    }
    else
    {
        if ((numeroBloque == this->numeroBloqueActual) && (numeroBuffer <= this->numeroBufferActual))
        {
            return this->bufferBinario[numeroBloque][numeroBuffer];
        }
        else
        {
            ///cout << endl << "La funcion obtenerBuffer informa que LA COMBINACION DE NUMERO DE BLOQUE Y NUMERO DE BUFFER AUN NO CONTIENE DATOS" << endl;
            ///cout << "LA COMBINACION DE NUMERO DE BLOQUE Y NUMERO DE BUFFER AUN NO CONTIENE DATOS" << endl;
        }
    }
}

//pre: numClave es un numero expresado en decimal y menor o igual a MAXIMOVALORQUESEPUEDEALMACENAR
//pre: cantidadDeBitsParaRepresentarla debe ser menor o igual a 32
// post: retorna 0 si la clave se agrego exitosamente y retorna -1 si la clave no pudo ser agregada
int BufferBinario::agregarClaveAlBuffer(unsigned int numClave, unsigned int cantidadDeBitsParaRepresentarla)
{

    if (this->entraClaveEnBuffer(cantidadDeBitsParaRepresentarla))
    {
        unsigned int numeroASumar= 0;
        unsigned int bitsQueOcupaLaClave= cantidadDeBitsParaRepresentarla;

        if (bitsQueOcupaLaClave <= cantidadBitsDisponibles)
        {
            numeroASumar= numClave << (cantidadBitsDisponibles - bitsQueOcupaLaClave);
            this->bufferBinario[this->numeroBloqueActual][this->numeroBufferActual] += numeroASumar;
            cantidadBitsDisponibles-= bitsQueOcupaLaClave;
        }
        else
        {
            numeroASumar = numClave >> (bitsQueOcupaLaClave - cantidadBitsDisponibles);
            this->bufferBinario[this->numeroBloqueActual][this->numeroBufferActual] += numeroASumar;

            if (this->numeroBufferActual < (CANTIDADBUFFERSINTERNOS - 1) )
            {
                this->numeroBufferActual++;
            }
            else
            {
                this->pasarANuevoBloque();
            }

            numeroASumar = numClave << (this->cantidadBitsMaximos - bitsQueOcupaLaClave + this->cantidadBitsDisponibles);
            this->bufferBinario[this->numeroBloqueActual][this->numeroBufferActual] += numeroASumar;
            this->cantidadBitsDisponibles= this->cantidadBitsMaximos - (bitsQueOcupaLaClave - this->cantidadBitsDisponibles);

        }
        if (this->cantidadBitsDisponibles==0)
        {
            if (this->numeroBufferActual < (CANTIDADBUFFERSINTERNOS - 1) )
            {
                this->numeroBufferActual++;
                this->cantidadBitsDisponibles= this->cantidadBitsMaximos;
            }
            else
            {
                this->pasarANuevoBloque();
            }
        }
        return 0;
    }
    else
    {
        return -1;
        //cout << endl << "Funcion agregarClaveAlBuffer informa que no hay espacio para almacenar nuevas claves" << endl;
        //cout << "LA CLAVE NO PUDO SER ALMACENADA PORQUE NO HAY ESPACIO" << endl;
    }
}

// crea en memoria dinámica un nuevo bloque de celdas (o buffers)
// Retorna 0 si el bloque nuevo se pudo crear con exito, o -1 si el bloque no se pudo crear
int BufferBinario::pasarANuevoBloque()
{
    if (numeroBloqueActual < CANTIDADBUFFERSINTERNOS -1)
    {
        if (this->cantidadBitsDisponibles==0)
        {
            this->cantidadBitsDisponibles= this->cantidadBitsMaximos;
        }
        this->numeroBloqueActual++;
        this->bufferBinario[this->numeroBloqueActual]= new unsigned int [CANTIDADBUFFERSINTERNOS];
        for(int x=0; x< CANTIDADBUFFERSINTERNOS; x++)
        {
            this->bufferBinario[numeroBloqueActual][x]= 0;
        }
        this->numeroBufferActual=0;
        return 0;
    }
    else
    {
        return -1;
        ///cout << endl << "Funcion pasarANuevoBloque informa que se han llenado todos los bloques" << endl;
        ///cout << "SE HAN LLENADO TODOS LOS BLOQUES" << endl;
        ///cout << "CUALQUIER RESULTADO OBTENIDO DESPUES DE ESTE MENSAJE ES INVALIDO" << endl;
        ///cout << "ACA SE DEBERIA ABORTAR EL PROGRAMA" << endl;
    }
}

// cantidadDeBitsALeer debe ser menor o igual a 31
// lee una determinada cantidad de bits de archivo, y avanza el posicion de lectura
// (atencion, dicho cursor no puede volverse para atras individualmente, solo se permite reinicializarLectura,
// que vuelve el cursor de lectura al comienzo del archivo
// post: devuelve la clave leida, o 50000 si por algun motivo no se pudo leer la clave (ej: ya fueron leidas todas las claves)
unsigned int BufferBinario::obtenerNumClave(unsigned int cantidadDeBitsALeer)
{
    if (this->quedanClavesPorLeer(cantidadDeBitsALeer))
    {
        unsigned int numClave= 0;
        if ((this->cantidadBitsMaximos - this->posicionDeLecturaActual) >= cantidadDeBitsALeer)
        {
            numClave= bufferBinario[this->numeroBloqueLecturaActual][this->numeroBufferDeLecturaActual] << this->posicionDeLecturaActual;
            numClave= numClave >> (this->cantidadBitsMaximos - cantidadDeBitsALeer);
            this->posicionDeLecturaActual+=cantidadDeBitsALeer;
        }
        else
        {
            unsigned int nibbleSuperior= this->bufferBinario[this->numeroBloqueLecturaActual][this->numeroBufferDeLecturaActual] << this->posicionDeLecturaActual;
            nibbleSuperior= nibbleSuperior >> (this->cantidadBitsMaximos - cantidadDeBitsALeer);

            if (this->numeroBufferDeLecturaActual < (CANTIDADBUFFERSINTERNOS - 1) )
            {
                this->numeroBufferDeLecturaActual++;
            }
            else
            {
                if (this->numeroBloqueLecturaActual < (CANTIDADBUFFERSINTERNOS -1))
                {
                    this->numeroBloqueLecturaActual++;
                    this->numeroBufferDeLecturaActual=0;
                }
                else
                {
                    ///cout << "NO QUEDAN CLAVES POR LEER" << endl;
                    return 50000;
                }
            }

            unsigned int nibbleInferior= this->bufferBinario[this->numeroBloqueLecturaActual][this->numeroBufferDeLecturaActual] >> ( 2* this->cantidadBitsMaximos - cantidadDeBitsALeer - this->posicionDeLecturaActual);
            this->posicionDeLecturaActual= cantidadDeBitsALeer - (this->cantidadBitsMaximos - this->posicionDeLecturaActual);

            numClave= nibbleSuperior | nibbleInferior;
        }
///*
        if (this->posicionDeLecturaActual==32)
        {
            this->posicionDeLecturaActual= 0;
            if (this->numeroBufferDeLecturaActual < (CANTIDADBUFFERSINTERNOS - 1) )
            {
                this->numeroBufferDeLecturaActual++;
            }
            else
            {
                if (this->numeroBloqueLecturaActual < (CANTIDADBUFFERSINTERNOS -1))
                {
                    this->numeroBloqueLecturaActual++;
                    this->numeroBufferDeLecturaActual=0;
                }
                else
                {
                    ///cout << "NO QUEDAN CLAVES POR LEER" << endl;
                    return 50000;

                }
            }
        }//*/
        return numClave;
    }
    else
    {
        ///cout << "NO QUEDAN CLAVES POR LEER" << endl;
        return 50000;

    }

}

void BufferBinario::guardarEnArchivoBufferCompleto(char * nombreArchivoSalida)
{
    ofstream fsalida(nombreArchivoSalida, ios::out | ios::binary);

    for(unsigned int x=0; x <= this->numeroBloqueActual; x++)
    {
        if (x != this->numeroBloqueActual)
        {
            fsalida.write(reinterpret_cast<char *>(this->bufferBinario[x]), this->tamanioBloqueEnBytes);
        }
        else
        {
            //objecion: falta el padding o relleno para el ultimo bloque
            // no importa, porque como despues guardo la cantidad de bits disponibles, no va a leer mas alla
            fsalida.write(reinterpret_cast<char *>(this->bufferBinario[x]), (this->numeroBufferActual + 1) * this->tamanioBufferEnBytes);
        }
    }
    char auxiliar[1];
    auxiliar[0]= this->cantidadBitsDisponibles;
    fsalida.write(auxiliar, 1);
    fsalida.close();
}

// recupera la estructura buffer completa que haya sido volcada a un archivo mediante la funcion guardarEnArchivoBufferCompleto
// mantiene todos los valores que tenía originalmente
// pre: debe reinicializarse el buffer antes de llamarla, o el bloque debe haber sido recien creado
void BufferBinario::leerDesdeArchivoBufferCompleto(char * nombreArchivoEntrada)
{

    unsigned int tamanioEnBytesDelArchivo= this->obtenerTamanioArchivoEnBytes(nombreArchivoEntrada) -1;
    double tamanioEnBytesDelArchivoDouble= tamanioEnBytesDelArchivo;
    unsigned int cantidadDeBloquesACrear= (unsigned int)ceil(tamanioEnBytesDelArchivoDouble / this->tamanioBloqueEnBytes);

    ifstream fentrada(nombreArchivoEntrada, ios::in | ios::binary);
    for (unsigned int x=1; x < cantidadDeBloquesACrear; x++)
    {
        this->bufferBinario[x]= new unsigned int [CANTIDADBUFFERSINTERNOS];
    }

    for (unsigned int x=0; x < (cantidadDeBloquesACrear - 1) ; x++)
    {
        fentrada.read((char *)(this->bufferBinario[x]), this->tamanioBloqueEnBytes);
    }

    unsigned int cantidadBytesDelUltimoBloque= tamanioEnBytesDelArchivo - ((cantidadDeBloquesACrear -1 ) * this->tamanioBloqueEnBytes);
    fentrada.read((char *)(this->bufferBinario[cantidadDeBloquesACrear - 1]), cantidadBytesDelUltimoBloque);

    char auxiliar[1];
    fentrada.read(auxiliar, 1);
    this->cantidadBitsDisponibles= auxiliar[0];

    fentrada.close();

    this->numeroBufferActual= (cantidadBytesDelUltimoBloque / 4) -1;
    this->numeroBloqueActual= cantidadDeBloquesACrear -1;
}

void BufferBinario::reinicializarLectura()
{
    this->posicionDeLecturaActual=0;
    this->numeroBufferDeLecturaActual=0;
    this->numeroBloqueLecturaActual=0;
}

unsigned int BufferBinario::obtenerTamanioArchivoEnBytes(char * nombreArchivo)
{
    ifstream fentrada(nombreArchivo, ios::in | ios::binary);
    fentrada.seekg(0, ios::end);
    unsigned int tamanioEnBytesDelArchivo= fentrada.tellg();
    fentrada.close();
    return tamanioEnBytesDelArchivo;
}

// cantidadDeBitsParaRepresentarla debe ser menor o igual a 32
int BufferBinario::entraClaveEnBuffer(unsigned int cantidadDeBitsParaRepresentarla)
{
    if (this->numeroBloqueActual < (CANTIDADBUFFERSINTERNOS -1) )
    {
        return 1;
    }
    else
    {
        if (this->numeroBloqueActual== (CANTIDADBUFFERSINTERNOS -1))
        {
            if (this->numeroBufferActual < (CANTIDADBUFFERSINTERNOS -1))
            {
                return 1;
            }
            else
            {
                if ((this->numeroBufferActual == (CANTIDADBUFFERSINTERNOS -1)) && (cantidadBitsDisponibles > cantidadDeBitsParaRepresentarla))
                {
                    return 1;
                }
                else
                {
                    ///cout << endl << "Funcion entraClaveEnBuffer informa que no hay espacio suficiente en la estructura para almacenar la clave" << endl;
                    ///cout << "NO HAY ESPACIO SUFICIENTE PARA ALMACENAR LA CLAVE" << endl;
                    ///cout << "LA CLAVE NO HA SIDO ALMACENADA" << endl;
                    return 0;
                }
            }
        }
    }

}

// para hacer eso necesitaria saber cuantos bits tiene la clave que se desean leer
// cantidadDeBitsParaRepresentarla debe ser menor o igual a 32
int BufferBinario::quedanClavesPorLeer(unsigned int cantidadDeBitsParaRepresentarla)
{

    if (this->numeroBloqueLecturaActual < this->numeroBloqueActual)
    {
        return 1;

    }
    else
    {
        if (this->numeroBloqueLecturaActual == this->numeroBloqueActual)
        {
            if(this->numeroBufferDeLecturaActual < this->numeroBufferActual)
            {
                return 1;
            }
            else
            {
                if ((this->numeroBufferDeLecturaActual == this->numeroBufferActual) && ((this->cantidadBitsDisponibles + this->posicionDeLecturaActual) < this->cantidadBitsMaximos))
                {
                    return 1;
                }
                else
                {
                    //cout << "NO QUEDAN CLAVES POR LEER" << endl;
                    return 0;
                }
            }
        }
    }
}


void BufferBinario::cargarBufferDeSoloLectura(char * nombreArchivoEntrada)
{

    unsigned int tamanioEnBytesDelArchivo= this->obtenerTamanioArchivoEnBytes(nombreArchivoEntrada);
    double tamanioEnBytesDelArchivoDouble= tamanioEnBytesDelArchivo;
    unsigned int cantidadDeBloquesACrear= (unsigned int)ceil(tamanioEnBytesDelArchivoDouble / this->tamanioBloqueEnBytes);

    ifstream fentrada(nombreArchivoEntrada, ios::in | ios::binary);
    for (unsigned int x=1; x < cantidadDeBloquesACrear; x++)
    {
        this->bufferBinario[x]= new unsigned int [CANTIDADBUFFERSINTERNOS];
    }

    for (unsigned int x=0; x < (cantidadDeBloquesACrear - 1) ; x++)
    {
        fentrada.read((char *)(this->bufferBinario[x]), this->tamanioBloqueEnBytes);
    }

    unsigned int cantidadBytesDelUltimoBloque= tamanioEnBytesDelArchivo - ((cantidadDeBloquesACrear -1 ) * this->tamanioBloqueEnBytes);
    fentrada.read((char *)(this->bufferBinario[cantidadDeBloquesACrear - 1]), cantidadBytesDelUltimoBloque);

    fentrada.close();

    this->numeroBufferActual= (cantidadBytesDelUltimoBloque / 4) -1;
    this->numeroBloqueActual= cantidadDeBloquesACrear -1;
}
