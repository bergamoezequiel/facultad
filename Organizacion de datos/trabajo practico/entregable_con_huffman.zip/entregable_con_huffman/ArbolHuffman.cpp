#include "ArbolHuffman.h"
#include <queue>
#include <vector>
#include <stack>
#include <deque>
#include <map>
#include <exception>
#include <string>
#include <iostream>
#include <cstdlib>
#include <sstream>

using namespace std;

typedef map<string, string> mapType;

string convertirIntAString(unsigned int intToString)
{
ostringstream stm;
stm << intToString;
return stm.str();
}

int convertirStringAInt(string stringToInt)
{
return atoi(stringToInt.c_str());
}

void convertirBinarioAChar(char &repBinariaUno, char &repBinariaDos, unsigned int binario)
{
string codigo = "";
string codUno;
string codDos;

do
{
if ((binario & 1) == 0)
{
codigo += "0";
}
else
{
codigo += "1";
}
binario >>= 1;
} while (binario);


while(codigo.length() < 16)
{
codigo += "0";
}

codigo = string(codigo.rbegin(), codigo.rend());
codUno = codigo.substr(8, 16);
codDos = codigo.substr(0, 8);
repBinariaUno = strtol(codUno.c_str(), 0, 2);
repBinariaDos = strtol(codDos.c_str(), 0, 2);
}

int encontrarMediana(const vector<INodoHuffman*> &vector, int inicio, int fin)
{
	INodoHuffman* primero = vector[inicio];
	INodoHuffman* medio = vector[inicio + (fin - inicio)/2];
	INodoHuffman* ultimo = vector[fin];

	// Los caracteres nunca van a ser iguales (no se repiten)
	if (primero->caracter < medio->caracter && medio->caracter < ultimo->caracter)
	{
		return inicio + (fin - inicio)/2;
	}
	else if (medio->caracter < primero->caracter && primero->caracter < ultimo->caracter)
	{
		return inicio;
	}
	else
	{
		return fin;
	}
}

int particionHuffman(vector<INodoHuffman*> &vector, int inicio, int fin)
{
	int pivot = encontrarMediana(vector, inicio, fin);
	int izq = inicio;
	int der = fin;
	INodoHuffman* aux;

	while (izq < der)
	{
		while (vector[der]->caracter > vector[pivot]->caracter)
		{
			der--;
		}

		// Los caracteres no pueden ser iguales (no hay repeticiones)
		while ((izq < der) && (vector[izq]->caracter < vector[pivot]->caracter))
		{
			izq++;
		}

		if (izq < der)
		{
			aux = vector[izq];
			vector[izq] = vector[der];
			vector[der] = aux;
		}
	}

	return der;
}

INodoHuffman::INodoHuffman(int f, std::string c, INodoHuffman* d, INodoHuffman* i, bool es)
{
	this->frecuencia = f;
	this->caracter = c;
	this->nodoDer = d;
	this->nodoIzq = i;
	this->esInterno = es;
}

INodoHuffman::~INodoHuffman()
{
	if (this->nodoDer != NULL)
	{
		delete this->nodoDer;
	}
	if (this->nodoIzq != NULL)
	{
		delete this->nodoIzq;
	}
}


bool ComparadorNodosHuffman::operator ()(const INodoHuffman* izquierdo, const INodoHuffman* derecho)
{
	if (!izquierdo->esInterno)
	{
		if (!derecho->esInterno)
		{
			return ((izquierdo->frecuencia > derecho->frecuencia) || (izquierdo->frecuencia == derecho->frecuencia && izquierdo->caracter > derecho->caracter));
		}
		else
		{
			return (izquierdo->frecuencia > derecho->frecuencia);
		}
	}
	else
	{
		return (izquierdo->frecuencia > derecho->frecuencia);
	}
}

INodoHuffman* construirArbolHuffman(vector<INodoHuffman*> &frecuencias)
{
	priority_queue<INodoHuffman*, vector<INodoHuffman*>, ComparadorNodosHuffman> arbol;

	int checkFrecuencias = 0;

	// Empiezo con todos los nodos hojas
	for (unsigned int i = 0; i < frecuencias.size(); i++)
	{
		if (frecuencias[i]->frecuencia != 0)
		{
			arbol.push(new INodoHuffman(frecuencias[i]->frecuencia, frecuencias[i]->caracter, NULL, NULL, false));
		}
		checkFrecuencias += frecuencias[i]->frecuencia;
	}

	// Empiezo a unir las hojas en nodos de mayor frecuencia
	while (arbol.size() > 1)
	{
		INodoHuffman* nodoDer = arbol.top();
		arbol.pop();

		INodoHuffman* nodoIzq = arbol.top();
		arbol.pop();

		INodoHuffman* padre = new INodoHuffman(nodoDer->frecuencia + nodoIzq->frecuencia, "", nodoDer, nodoIzq, true);
		arbol.push(padre);
	}

	if (arbol.top()->frecuencia != checkFrecuencias)
	{
		throw new exception();
	}

	return arbol.top();
}

void escribirCodigosHuffman(const INodoHuffman* raiz, const string &codigo, mapType &codigos)
{
	if (!raiz->esInterno)
	{
		codigos[raiz->caracter] = codigo;
	}
	else
	{
		string codigoIzq = codigo;
		codigoIzq += "0";
		escribirCodigosHuffman(raiz->nodoIzq, codigoIzq, codigos);

		string codigoDer = codigo;
		codigoDer += "1";
		escribirCodigosHuffman(raiz->nodoDer, codigoDer, codigos);
	}
}

string encontrarHojaPorCodigo(const string &codigo, const map<string, string > &raiz)
{
	for (map<string, string >::const_iterator it = raiz.begin(); it != raiz.end(); it++)
	{
		if (it->second == codigo)
		{
			return it->first;
		}
	}
	return "|$NYT$|";
}

void ordernarVectorFrecuencias(vector<INodoHuffman*> &frecuencias)
{
	stack<int> pila;
	pila.push(0);
	pila.push(frecuencias.size() - 1);
	while (!pila.empty())
	{
		int fin = pila.top();
		pila.pop();
		int inicio = pila.top();
		pila.pop();

		if (fin - inicio < 2)
		{
			continue;
		}
		int pivot = particionHuffman(frecuencias, inicio, fin);

		pila.push(pivot + 1);
		pila.push(fin);

		pila.push(inicio);
		pila.push(pivot);
	}

}

INodoHuffman* encontrarNodoHoja(string caracter, const vector<INodoHuffman*> &frecuencias)
{
	int izq = 0;
	int der = frecuencias.size() - 1;

	/*while(der >= izq)
	{
		int medio = izq + (der - izq)/2;

		if (caracter < frecuencias[medio]->caracter)
		{
			der = medio - 1;
		}
		else if (caracter > frecuencias[medio]->caracter)
		{
			izq = medio + 1;
		}
		else
		{
			return frecuencias[medio];
		}
	}
	*/
	// No se encontró: el vector está desordenado. Se sigue con búsqueda secuencial
	for (int i = 0; i < frecuencias.size(); i++)
	{
		if (frecuencias[i]->caracter == caracter)
		{
			return frecuencias[i];
		}
	}
	return NULL;
}

unsigned int convertirStringABinario(const string &codigoBin)
{
	if (codigoBin == "")
	{
		return 0;
	}

	unsigned int binario = 0;
	for (int i = codigoBin.length(); i > 0; i--)
	{
		binario |= (codigoBin[codigoBin.length() - i] == '1' ? 1 : 0) << (i-1);
	}

	return binario;
}

INodoHuffman* construirArbolInicial(vector<INodoHuffman*> &frecuencias)
{
	frecuencias.push_back(new INodoHuffman(1, "|$NYT$|", NULL, NULL, false));
	for (int i = 0; i<256; i++){
		char caracter=i;
		string charstr = "";
		charstr += caracter;
		INodoHuffman* nuevaHoja = new INodoHuffman(1, charstr, NULL, NULL, false);
		frecuencias.push_back(nuevaHoja);
		INodoHuffman* nyt = encontrarNodoHoja("|$NYT$|", frecuencias);
		nyt->frecuencia = nyt->frecuencia + 1;
	}

	return construirArbolHuffman(frecuencias);
}

void escribirArchivoHuffman(char* salida, BufferBinario &bufferLectura, Tabla &tabla)
{
	BufferBinario bufferEscritura;
	vector<INodoHuffman*> frecuencias;
	map<string, string > codigos;

	INodoHuffman* raiz;
	unsigned int cantBits = 9;
	unsigned int clavesGuardadas = 255;
	char repBinariaUno;
	char repBinariaDos;
	int i = 1;
	if (bufferLectura.quedanClavesPorLeer(cantBits))
	{
		// La primera representación binaria se lee y se escribe completa
		unsigned int clave = bufferLectura.obtenerNumClave(cantBits);
		bufferEscritura.agregarClaveAlBuffer(clave, cantBits);

		// Se agrega el caracter leído al vector de frecuencias
		frecuencias.push_back(new INodoHuffman(1, convertirIntAString(clave), NULL, NULL, false));

		// Se construye el árbol Huffman con esos nodos
		raiz = construirArbolHuffman(frecuencias);

		// Se consiguen los códigos
		escribirCodigosHuffman(raiz, "", codigos);

		clavesGuardadas++;

		// Se empieza a leer el resto
		while(bufferLectura.quedanClavesPorLeer(cantBits))
		{
			clave = bufferLectura.obtenerNumClave(cantBits);
			string claveString = convertirIntAString(clave);
			INodoHuffman* nodo = encontrarNodoHoja(claveString, frecuencias);

			if (nodo == NULL)
			{
				// Caracter nuevo

				// Código de NYT que avisa que viene un caracter nuevo
				bufferEscritura.agregarClaveAlBuffer(0, 1);

				// Clave entera a agregar
				// Se guarda en el buffer
				bufferEscritura.agregarClaveAlBuffer(clave, cantBits);

				// Se agrega la clave leída en el vector de frecuencias
				frecuencias.push_back(new INodoHuffman(1, claveString, NULL, NULL, false));

				// Se construye el árbol Huffman con esos nodos
				delete raiz;
				raiz = construirArbolHuffman(frecuencias);
				// Se consiguen los códigos
				escribirCodigosHuffman(raiz, "", codigos);
			}
			else
			{
				// Caracter ya visto

				// Código de NYT que avisa que viene un caracter nuevo
				bufferEscritura.agregarClaveAlBuffer(1, 1);
				// Se encuentra su código Huffman
				string claveVista = codigos[nodo->caracter];
				// En modo binario (unsigned int)
				unsigned int claveBinaria = convertirStringABinario(claveVista);
				// Se guarda en el buffer
				bufferEscritura.agregarClaveAlBuffer(claveBinaria, claveVista.length());

				// Se suma 1 a la frecuencia del nodo encontrado
				nodo->frecuencia++;
			}

			clavesGuardadas++;
			i++;
			if (clavesGuardadas >= pow((int)2, cantBits)-1 && cantBits < 14)
			{
				cout << "+1 bit: " << i << endl;
				cantBits++;
			}
		}

	}

	// Se escribe archivo
	bufferEscritura.guardarEnArchivoBufferCompleto(salida);

}

void leerArchivoHuffman(char* entrada, BufferBinario &bufferSalida)
{
	BufferBinario bufferLectura;
	vector<INodoHuffman*> frecuencias;
	map<string, string > codigos;
	Tabla tabla;
	INodoHuffman* raiz;
	unsigned int cantBits = 9;
	unsigned int clavesGuardadas = 255;
	char repBinariaUno;
	char repBinariaDos;
	int i = 1;
	// Se abre el archivo a descomprimir
	bufferLectura.leerDesdeArchivoBufferCompleto(entrada);

	// Se fija si tiene algo, si lo tiene lee los primeros 9 bits
	if (bufferLectura.quedanClavesPorLeer(cantBits))
	{
		unsigned int clave = bufferLectura.obtenerNumClave(cantBits);
		string claveStr = convertirIntAString(clave);

		// Se escribe en el buffer de salida directamente
		bufferSalida.agregarClaveAlBuffer(clave, cantBits);

		// Se añade al vector de frecuencias
		frecuencias.push_back(new INodoHuffman(1, claveStr, NULL, NULL, false));

		// Se construye el árbol Huffman con esos nodos
		raiz = construirArbolHuffman(frecuencias);

		// Se consiguen los códigos
		escribirCodigosHuffman(raiz, "", codigos);

		clavesGuardadas++;

		// Se siguen con los siguientes códigos. Se leen de a bits
		while(bufferLectura.quedanClavesPorLeer(1))
		{
			// Se fija si el próximo se guardó como literal o por el código del
			// Huffman
			bool esElProximoLiteral = bufferLectura.obtenerNumClave(1) == 0;

			if (esElProximoLiteral)
			{
				// Se leen los X bits del literal
				clave = bufferLectura.obtenerNumClave(cantBits);
				claveStr = convertirIntAString(clave);

				// Se agregan al buffer de salida
				bufferSalida.agregarClaveAlBuffer(clave, cantBits);

				// Se agrega la clave al vector de frecuencias
				frecuencias.push_back(new INodoHuffman(1, claveStr, NULL, NULL, false));

				// Se construye el árbol Huffman con esos nodos
				delete raiz;
				raiz = construirArbolHuffman(frecuencias);
				// Se consiguen los códigos
				escribirCodigosHuffman(raiz, "", codigos);
			}
			else
			{
				// Si sólo hay un código, es el único que está
				if (codigos.size() == 1)
				{
					string claveVista = codigos[""];
					// En modo binario (unsigned int)
					unsigned int claveBinaria = convertirStringABinario(claveVista);
					// Se guarda en el buffer
					bufferSalida.agregarClaveAlBuffer(claveBinaria, 1);
					// Se suma 1 a la frecuencia de ese nodo
					INodoHuffman* nodo = encontrarNodoHoja("", frecuencias);
					nodo->frecuencia++;
				}
				else
				{
					bool noEsHoja = true;
					string codigo = "";
					while (bufferLectura.quedanClavesPorLeer(1) && noEsHoja)
					{
						unsigned int bit = bufferLectura.obtenerNumClave(1);
						codigo += bit == 1 ? "1" : "0";
						string claveVista = encontrarHojaPorCodigo(codigo, codigos);
						if (claveVista != "|$NYT$|")
						{
							unsigned int claveBinaria = convertirStringAInt(claveVista);
							bufferSalida.agregarClaveAlBuffer(claveBinaria, cantBits);

							// Se busca el nodo en el vector de frecuencias para
							// incrementar su frecuencia
							INodoHuffman* nodoHoja = encontrarNodoHoja(claveVista, frecuencias);
							nodoHoja->frecuencia++;
							noEsHoja = false;
						}
					}
				}
			}

			clavesGuardadas++;
			i++;
			if (clavesGuardadas >= pow((int)2, cantBits)-1 && cantBits < 14)
			{
				cout << "+1 bit: " << i << endl;
				cantBits++;
			}
		}
	}
}

char* convertirCodigoAChar(const std::vector<bool> &codigo)
{
char codChar[2];
string eightBitCode = "";
int bits = 0;
for (int i = codigo.size()-1; i >= 0 && bits < 8; i--)
{
eightBitCode += codigo[i] ? "1" : "0";
bits++;
}
char charEightBitCode = strtol(eightBitCode.c_str(), (char**)NULL, 2);
codChar[0] = charEightBitCode;

if (codigo.size() > 8)
{
eightBitCode = "";
if ((codigo.size() - bits) % 8 != 0)
{
for (int i = 0; i < 8 - (codigo.size() - bits); i++)
{
eightBitCode += "0";
}
}
for (int i = codigo.size() - bits - 1; i >= 0; i--)
{
eightBitCode += codigo[i] ? "1" : "0";
}
charEightBitCode = strtol(eightBitCode.c_str(), (char**)NULL, 2);
}
else
{
charEightBitCode = strtol("00000000", (char**)NULL, 2);
}
codChar[1] = charEightBitCode;

return codChar;
}

