#ifndef BUFFERBINARIO_H
#define BUFFERBINARIO_H

#define CANTIDADBUFFERSINTERNOS 15000       //debe ser menor que sizeof (unsigned int)

class BufferBinario
{

public:
    BufferBinario();        // Constructor
    ~BufferBinario();   // Destructor

    //pre: numClave es un numero expresado en decimal y menor o igual a MAXIMOVALORQUESEPUEDEALMACENAR
    // cantidadDeBitsParaRepresentarla debe ser menor o igual a 32
    // post: retorna 0 si la clave se agrego exitosamente y retorna -1 si la clave no pudo ser agregada
    int agregarClaveAlBuffer(unsigned int numClave, unsigned int cantidadDeBitsParaRepresentarla);

    //devuelve una celda determinada de la estructura (es lo que se llama BUFFER)
    // solo debería utilizarse desde fuera de la clase con el objeto de testearla
    unsigned int obtenerBuffer(unsigned int numeroBloque, unsigned int numeroBuffer);
    //int obtenerBitsQueOcupaLaClave(unsigned int numClave);

    // cantidadDeBitsALeer debe ser menor o igual a 31
    // lee una determinada cantidad de bits de archivo, y avanza el posicion de lectura
    // (atencion, dicho cursor no puede volverse para atras individualmente, solo se permite reinicializarLectura,
    // que vuelve el cursor de lectura al comienzo del archivo
    // post: devuelve la clave leida, o 50000 si por algun motivo no se pudo leer la clave (ej: ya fueron leidas todas las claves)
    unsigned int obtenerNumClave(unsigned int cantidadDeBitsALeer);

    // elimina todos los datos de la estructura, y queda como si solo hubiera actuado el contructor
    void reinicializarBuffer();

    // vuelve al comienzo de la estructura el cursor de lectura
    void reinicializarLectura();

    // guarda la estructura buffer completa a un archivo
    void guardarEnArchivoBufferCompleto(char * nombreArchivoSalida);

    // recupera la estructura buffer completa que haya sido volcada a un archivo mediante la funcion guardarEnArchivoBufferCompleto
    // mantiene todos los valores que tenía originalmente
    // pre: debe reinicializarse el buffer antes de llamarla, o el bloque debe haber sido recien creado
    void leerDesdeArchivoBufferCompleto(char * nombreArchivoEntrada);

    // cantidadDeBitsParaRepresentarla debe ser menor o igual a 32
    // dada una determinada cantidad de bits, indica si hay espacio suficiente en el buffer para almacenarla
    int entraClaveEnBuffer(unsigned int cantidadDeBitsParaRepresentarla);

    // cantidadDeBitsParaRepresentarla debe ser menor o igual a 32
    // devuelve 1 si hay claves de la cantidad de bits indicada para leer en el buffer
    // o 1 en caso contrario
    int quedanClavesPorLeer(unsigned int cantidadDeBitsParaRepresentarla);

    //Carga en memoria un archivo completo, y luego solo se permite obtenerNumClave(8),
    //ya que el archivo va a actuar como de solo lectura
    void cargarBufferDeSoloLectura(char * nombreArchivoEntrada);

    //void guardarEnArchivoBufferNumero(char * nombreArchivoEntrada, unsigned int numeroBuffer);

private:

    // obs: cantidad de buffers internos es igual a cantidad de bloques internos
    // buffers son las celdas, bloques son los arreglos de celdas


    unsigned int tamanioBufferEnBytes;
    unsigned int tamanioBloqueEnBytes;
    unsigned int cantidadBitsMaximos;
    unsigned int * bufferBinario[CANTIDADBUFFERSINTERNOS];
    unsigned int numeroBloqueActual;
    unsigned int numeroBloqueLecturaActual;
    unsigned int numeroBufferActual;
    unsigned int numeroBufferDeLecturaActual;
    unsigned int cantidadBitsDisponibles;
    unsigned int posicionDeLecturaActual;

    // crea en memoria dinámica un nuevo bloque de celdas (o buffers)
    // Retorna 0 si el bloque nuevo se pudo crear con exito, o -1 si el bloque no se pudo crear
    int pasarANuevoBloque();


    void establecerValoresPorDefecto();

    // elimina de memoria el contenido de todos los bloques y libera la memoria solicitada
    void vaciarBufferes();

    // devuelve el tamaño, en bytes, de un determinado archivo
    unsigned int obtenerTamanioArchivoEnBytes(char * nombreArchivoSalida);

};

#endif // BUFFERBINARIO_H
