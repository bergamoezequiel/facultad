/*
 * LimpiadorDeTabla.cpp
 *
 *  Created on: 08/06/2014
 *      Author: alumno
 */
#include <iostream>
using namespace std;
#include "LimpiadorDeTabla.h"
#include <stdio.h>
//#include "lista.h"
//#include "nodoTabla.h"

LimpiadorDeTabla::LimpiadorDeTabla(nodoTabla* listaDeNodos, int cantidadDeElementos)
{
    listaProvenienteDeTabla=listaDeNodos;
    comienzoDeBusquedaParaElProximoNull=255;
    comienzoDeBusquedaParaElProximoAUbicarseEnNull=CANTIDAD_MAXIMA_DE_ELEMENTOS-1;
    /*candidato a salir de la lista de nodos a limpiar*/
    nodoTabla* nodoConMayorFrecuencia=NULL;
    int posicionNodoConMayorFrecuencia=-1;
    nodosAVaciar= new Lista<nodoTabla*>;
    for (int i=256; i<CANTIDAD_MAXIMA_DE_ELEMENTOS-1-CANTIDAD_MAXIMA_DE_MAS_NUEVOS; i++)
    {
        nodoTabla* nodo =listaDeNodos+i;
        /*Si hay menos elementos que la cantidad de elementos a borrar lo agrega a la lista de elementos a borrar*/
        if (nodosAVaciar->getTamanio()<CANTIDAD_DE_ELEMENTOS_A_BORRAR)
        {
            nodosAVaciar->agregar(nodo);
            /*Si el nodo actual tiene frecuencia mayor a nodoConMayorFrecuencia este toma su lugar */
            if (nodoConMayorFrecuencia==NULL || nodoConMayorFrecuencia->getFrecuencia()<nodo->getFrecuencia())
            {
                nodoConMayorFrecuencia=nodo;
                posicionNodoConMayorFrecuencia=nodosAVaciar->getTamanio();
            }
        }
        /* Si la lista de elementos a borrar esta llena
           se fija el nodo de mayor frecuencia y lo reemplaza si es que el nodo tiene frecuencia mas baja que el mencionado anteriormente*/
        else
        {
            if (nodoConMayorFrecuencia->getFrecuencia()>nodo->getFrecuencia())
            {
                nodosAVaciar->eliminar(posicionNodoConMayorFrecuencia);
                nodosAVaciar->agregar(nodo);
                posicionNodoConMayorFrecuencia=recalcularPosicionNodoMayorFrecuencia();
                nodoConMayorFrecuencia=nodosAVaciar->getDato(posicionNodoConMayorFrecuencia);
            }
        }
    }

    this->limpiarLista(nodosAVaciar);
    this->agruparTabla();

    std::cout<< std::endl << std::endl << "<<<<<<<<<<<<<<<<<<<<<<Se limpio la tabla>>>>>>>>>>>>>>>>>>>"<< std::endl<< std::endl;
}


void LimpiadorDeTabla::limpiarLista(Lista<nodoTabla*>* nodosAVaciar)
{
    for (int i=1; i<=nodosAVaciar->getTamanio(); i++)
    {
        nodoTabla* nodo= nodosAVaciar->getDato(i);
        nodo->cambiarCaracteres("");
        nodo->setFrecuencia(0);
    }
}

int LimpiadorDeTabla::recalcularPosicionNodoMayorFrecuencia()
{
    int pos=1;
    nodoTabla* nodo1;
    nodoTabla* nodo2;
    for (int i=1; i<=nodosAVaciar->getTamanio(); i++)
    {
        nodo1=nodosAVaciar->getDato(pos);
        nodo2=nodosAVaciar->getDato(i);
        if (nodo1->getFrecuencia()<nodo2->getFrecuencia())
            pos=i;
    }
    return pos;
}

/* comienza desde el principio de la tabla hacia el final
 * devuelve nodo "borrado"*/
nodoTabla* LimpiadorDeTabla::irAlProximoNull()
{
    while (comienzoDeBusquedaParaElProximoNull<CANTIDAD_MAXIMA_DE_ELEMENTOS-2)
    {
        comienzoDeBusquedaParaElProximoNull++;
        nodoTabla* nodo = listaProvenienteDeTabla + comienzoDeBusquedaParaElProximoNull ;
        if ((nodo->getListaCaracteres())=="")
        {
            return nodo;
        }
    }
    return NULL;
}

nodoTabla* LimpiadorDeTabla:: irAlProximoAUbicarseEnNull()
{
    while (comienzoDeBusquedaParaElProximoAUbicarseEnNull>=257)
    {
        comienzoDeBusquedaParaElProximoAUbicarseEnNull--;
        nodoTabla* nodo = listaProvenienteDeTabla + comienzoDeBusquedaParaElProximoAUbicarseEnNull ;
        if ((nodo->getListaCaracteres())!="")
        {
            return nodo;
        }
    }
    return NULL;
}

/* Traspasa informacion entre nodos, no intercambia nodos, ya que esto produciria la perdida de su representacion binaria*/
void LimpiadorDeTabla::agruparTabla()
{
    nodoTabla* nodoNull= this->irAlProximoNull();
    nodoTabla* nodoAUbicarseEnNull= this->irAlProximoAUbicarseEnNull();

    while ((nodoNull!=NULL && nodoAUbicarseEnNull!=NULL) && (comienzoDeBusquedaParaElProximoNull < comienzoDeBusquedaParaElProximoAUbicarseEnNull))
    {
        nodoNull->cambiarCaracteres(nodoAUbicarseEnNull->getListaCaracteres());
        nodoNull->setFrecuencia(nodoAUbicarseEnNull->getFrecuencia());
        nodoAUbicarseEnNull->cambiarCaracteres("");
        nodoAUbicarseEnNull->setFrecuencia(0);
        nodoNull= this->irAlProximoNull();
        nodoAUbicarseEnNull= this->irAlProximoAUbicarseEnNull();
    }
}
