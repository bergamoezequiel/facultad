/*
 * ArbolHuffman.h
 *
 *  Created on: 25/05/2014
 *      Author: alumno
 */

#ifndef ARBOLHUFFMAN_H_
#define ARBOLHUFFMAN_H_

#include <map>
#include <vector>
#include <string>
#include "BufferBinario.h"
#include "Tabla.h"
const int CANT_CARACTERES = 6;

class INodoHuffman
{
	public:
		int frecuencia;
		std::string caracter;
		INodoHuffman* nodoDer;
		INodoHuffman* nodoIzq;
		bool esInterno;
		virtual ~INodoHuffman();
		INodoHuffman(int f, std::string c, INodoHuffman* d, INodoHuffman* i, bool es);
};

struct ComparadorNodosHuffman
{
	bool operator() (const INodoHuffman* izquierdo, const INodoHuffman* derecho);
};

INodoHuffman* construirArbolHuffman(std::vector<INodoHuffman*> &frecuencias);

void escribirCodigosHuffman(const INodoHuffman* raiz, const std::string &codigoHuffman, std::map<std::string, std::string> &codigosHuffman);

std::string encontrarHojaPorCodigo(const std::string &codigo, const std::map< std::string, std::string >  &codigos);

void ordernarVectorFrecuencias(std::vector<INodoHuffman*> &frecuencias);

INodoHuffman* encontrarNodoHoja(std::string caracter, const std::vector<INodoHuffman*> &frecuencias);

unsigned int convertirStringABinario(const std::string &codigoBin);

INodoHuffman* construirArbolInicial(std::vector<INodoHuffman*> &frecuencias);

void escribirArchivoHuffman(char* salida, BufferBinario &buffer, Tabla &tabla);
void leerArchivoHuffman(char* entrada, BufferBinario &bufferSalida);
#endif /* ARBOLHUFFMAN_H_ */
