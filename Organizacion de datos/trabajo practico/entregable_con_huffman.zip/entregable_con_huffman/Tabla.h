#ifndef TABLA_H_INCLUDED
#define TABLA_H_INCLUDED
#include "nodoTabla.h"
#include "LimpiadorDeTabla.h"
#include <map>
#include <string>
using namespace std;
const int CANTIDAD_INICIAL_DE_ELEMENTOS= 256;
//const int CANTIDAD_MAXIMA_DE_ELEMENTOS = 16384;  //cantidad de elementos que puedo tener con 14 bits



class Tabla
{
private:
    nodoTabla* listaDeNodos;
    int cantElementos;
    /* El proximo nodo que se crea, va a tener asociados estos dos bits como su representacion binaria*/
    unsigned char codigoProximoElemento[2];
    /*  incrementa en uno la representacion binaria, asi queda "preparada" para el proximo nodo a agregar*/
    void incrementarCodigoProximoElemento();
    /* cuando se llena la tabla este metodo es llamado para borrar nodos menos frecuentes*/
    void limpiarTabla();
    int comprime;

public:
    map<string,nodoTabla*> mapParaBusquedaPorClave;
    bool estaLlenaDesc();
    void limpiezaDesc();
    Tabla();
    ~Tabla();
    void mostrarTabla();
    /*Agrega los caracteres pasados por parametro a la tabla */
    nodoTabla* agregar(std::string caracteresAAgregar);
    int getCantidadDeElementos();
    /*PRECONDICION: la lista no tiene que esta vacia
    Devuelve true si hay un nodo que tenga almacenados los caracteres de la lista*/
    bool estaLaClave(std::string caracteres);
    /*Devuelve true si la tabla tiene la maxima cantidad de elementos posibles con 14 bits*/
    bool estaLlena();
    /*PRECONDICION:tiene que estar previamente hecha la verificacion de que este la clave
    * POSCONDICION: incrementa la frecuencia del nodo
    */
    nodoTabla* devolverNodoConClave(std::string caracteres);
    /*Devuelve true si algun nodo tiene la representacion binaria pasada por parametro*/
    bool estaLaRep(char repBina0,char repBina1, int cantidadDeBitsAComprar);
    /*PRECONDICION:tiene que estar previamente hecha la verificacion de que este la clave
    * POSCONDICION: incrementa la frecuencia del nodo
    */
    nodoTabla* devolverNodoConRepBinaria(char repBina0,char repBina1, int cantidadDeBitsAComprar);




};


#endif // TABLA_H_INCLUDED
