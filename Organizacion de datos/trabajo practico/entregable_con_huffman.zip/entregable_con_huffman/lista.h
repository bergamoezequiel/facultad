#ifndef LISTA_H
#define LISTA_H

#include <iostream>
#include "nodo.h"

template <class Dato>
class Lista
{
private:
    /* puntero al primer nodo de la lista */
    Nodo<Dato>* primero;
    /* cantidad de nodos en la lista */
    int tamanio;
    /* Puntero que sera utilizado como un cursor interno */
    Nodo<Dato>* cursor;

public:
    /*
     * post: crea una lista vacía
     */
    Lista();

    /*
     * post: libera recursos (nodos)
     */
    ~Lista();

    /*
     * post: devuelve TRUE si la lista no contiene ningún
     *       elemento, y FALSE en caso contrario
     */
    bool vacia();

    /*
     * pre: el tipo de dato de 'dato' debe ser igual al
     *      de los demás nodos de la lista
     * post: agrega un nodo con el dato proporcionado
     *       al final de la lista
     */
    void agregar(Dato& nuevoDato);

    /*
     * pre: la posición especificada debe ser mayor
     *      a cero y menor o igual al tamaño de la lista
     * post: elimina el nodo ubicado en la posicion
     *       especificada de la lista
     */
    void eliminar(int& posicion);

    /*
     * pre: la posición especificada debe ser mayor
     *      a cero y menor o igual al tamaño de la lista
     * post: devuelve el dato del nodo ubicado en la posicion
     *       especificada de la lista
     */
    Dato getDato(int& posicion);

    /*
     * pre: nuevoDato debe ser del mismo tipo de dato que los
     *      datos de los demás nodos de la lista.
     * post: asigna o modifica el dato del nodo ubicado en la
     *       posición especificada, asignandole nuevoDato.
     */
    void setDato(Dato& nuevoDato, int& posicion);

    /*
     * post: devuelve la cantidad de nodos alojados en la lista
     */
    int getTamanio();

    /*
     * post: imprime en pantalla una representación de la lista
     */
    void mostrar();

    /*
     * post: Situa el cursor interno de la lista en el primer elemento.
     */
    void irAlPrimero();

    /*
    * post: Si el cursor en la posicion actual apunta a algo, devuelve True.
    */
    bool existeElementoActual();

    /*
     * post: Devuelve el dato apuntado por el cursor interno de la lista.
     */
    Dato obtenerElementoActual();

    /*
     * post: El cursor interno de la lista avanza al siguiente nodo.
     */
    void irAlSiguiente();
};


template <class Dato>
Lista<Dato>::Lista()
{
    this->primero = NULL;
    this->tamanio = 0;
}

template <class Dato>
Lista<Dato>::~Lista()
{
    while(!this->vacia())
    {
        int posicion= 1;
        this->eliminar(posicion);
    }

}

template <class Dato>
bool Lista<Dato>::vacia()
{
    return ((this->tamanio == 0) ? true : false );
}

template <class Dato>
void Lista<Dato>::agregar(Dato& nuevoDato)
{
    if(!this->vacia())
    {
        Nodo<Dato>* nodoIterador = this->primero;

        while(nodoIterador->getSiguiente() != NULL)
        {
            nodoIterador = nodoIterador->getSiguiente();
        }

        nodoIterador->setSiguiente(new Nodo<Dato>(nuevoDato));
    }
    else
    {
        this->primero = new Nodo<Dato>(nuevoDato);
    }

    this->tamanio++;
}

template <class Dato>
void Lista<Dato>::eliminar(int& posicion)
{
    if(!this->vacia())
    {
        if(posicion == 1)
        {
            if(this->primero->getSiguiente() == NULL)
            {
                delete this->primero;
            }
            else
            {
                Nodo<Dato>* nuevoPrimero = this->primero->getSiguiente();
                delete this->primero;
                this->primero = nuevoPrimero;
            }
        }
        else
        {
            Nodo<Dato>* nodoAnterior = this->primero;

            for(int i=1; i<posicion-1; i++)
            {
                nodoAnterior = nodoAnterior->getSiguiente();
            }

            Nodo<Dato>* nodoABorrar = nodoAnterior->getSiguiente();
            Nodo<Dato>* nodoSiguiente = nodoABorrar->getSiguiente();

            delete nodoABorrar;

            nodoAnterior->setSiguiente(nodoSiguiente);
        }

        this->tamanio--;
    }
}

template <class Dato>
Dato Lista<Dato>::getDato(int& posicion)
{
    if(posicion == 1)
    {
        return this->primero->getDato();
    }
    else
    {
        Nodo<Dato>* nodoBuscado = this->primero;

        for(int i=1; i<posicion; i++)
        {
            nodoBuscado = nodoBuscado->getSiguiente();
        }

        return nodoBuscado->getDato();
    }
}

template <class Dato>
void Lista<Dato>::setDato(Dato& nuevoDato, int& posicion)
{
    if(posicion == 1)
    {
        this->primero->setDato(nuevoDato);
    }
    else
    {
        Nodo<Dato>* nodoBuscado = this->primero;

        for(int i=1; i<posicion; i++)
        {
            nodoBuscado = nodoBuscado->getSiguiente();
        }

        nodoBuscado->setDato(nuevoDato);
    }
}

template <class Dato>
int Lista<Dato>::getTamanio()
{
    return this->tamanio;
}

template <class Dato>
void Lista<Dato>::mostrar()
{
    if(!this->vacia())
    {
        Nodo<Dato>* nodoAMostrar = this->primero;
        std::cout << nodoAMostrar->getDato();

        while(nodoAMostrar->getSiguiente() != NULL)
        {
            nodoAMostrar = nodoAMostrar->getSiguiente();
            std::cout << nodoAMostrar->getDato();
        }
    }

}

template <class Dato>
void Lista<Dato>::irAlPrimero()
{
    this->cursor=this->primero;
}

template <class Dato>
bool Lista<Dato>::existeElementoActual()
{
    return (this->cursor != NULL);
}

template <class Dato>
Dato Lista<Dato>::obtenerElementoActual()
{
    return (cursor->getDato());
}

template <class Dato>
void Lista<Dato>::irAlSiguiente()
{
    this->cursor= cursor->getSiguiente();
}


#endif


