/*
 * nodoTabla.cpp
 *
 *  Created on: 08/06/2014
 *      Author: alumno
 */

#include "nodoTabla.h"
//#include "lista.h"

using namespace std;

void nodoTabla::setNodoTabla(string aAgregar,char primerCaracterRepBi,char segundoCaracterRepBina)
{
    repBinaria[0]=primerCaracterRepBi;
    repBinaria[1]=segundoCaracterRepBina;
    caracteres = aAgregar;
    if (aAgregar!="")
        frecuencia=1;
    else frecuencia=0;

}

nodoTabla::nodoTabla() {}

string nodoTabla::getListaCaracteres()
{
    return caracteres;
}

nodoTabla::~nodoTabla()
{
}


void nodoTabla::incrementarFrecuencia()
{
    frecuencia++;
}

void nodoTabla::setFrecuencia(int valor)
{
    frecuencia=valor;
}
long int nodoTabla::getFrecuencia()
{
    return frecuencia;
}

/* muestra el codigo que representa a la secuencia de caracteres, luego "--" y por ultimo el codigo*/
void nodoTabla::mostrarCaracteres()
{
    cout<<"Rep. Binaria: "<<(int)repBinaria[0]<<" "<<(int)repBinaria[1]<<"   ";

    cout<<"Caracteres: ";
    if (caracteres=="")
        cout<<"'nula'";
    else
    {
        cout << caracteres;
    }
    cout<<" frecuencia: "<<frecuencia << endl;
}


void nodoTabla::cambiarCaracteres(string aCambiar)
{
    caracteres = aCambiar;
}
bool nodoTabla::contiene(string lista)
{
    return (caracteres == lista);
}

bool nodoTabla::tieneRepBinaria(unsigned char primer,unsigned char segundo, int cantidadAComparar)
{
    /*cantidad de bits a tener en cuenta del primer caracter ej: 11 bits , num=3 */
    int num= cantidadAComparar-8;
    /* a la cantidad de bits a tener en cuenta los pongo 1 , y los demas en 0 */
    unsigned char cantidadDeBitsEnUno= pow(2,num)-1;
    /* Haciendo un AND bit a bit, descarta todo aquello que no me interese, ej: 11 bit, a los 5 ultimos los pone en 0 */
    primer= primer & cantidadDeBitsEnUno;
    if(primer==repBinaria[0] && segundo==repBinaria[1])
        return true;
    return false;
}

bool nodoTabla::tieneMenorRepresentacionBinariaQue(unsigned char repBina0,unsigned char repBina1,int cantidadDeBitsAComprar)
{
    /*cantidad de bits a tener en cuenta del primer caracter ej: 11 bits , num=3 */
    int num= cantidadDeBitsAComprar-8;
    /* a la cantidad de bits a tener en cuenta los pongo 1 , y los demas en 0 */
    unsigned char cantidadDeBitsEnUno= pow(2,num)-1;
    /* Haciendo un AND bit a bit, descarta todo aquello que no me interese, ej: 11 bit, a los 5 ultimos los pone en 0 */
    repBina0= repBina0 & cantidadDeBitsEnUno;
    if((int) repBinaria[0]<(int)repBina0)
        return true;
    else if ((int) repBinaria[0]==(int)repBina0)
        if((int) repBinaria[1]<(int)repBina1)
            return true;
    return false;
}
