# Mi primer shell
#Ej si se llama hola.sh 3 4 2 
HOY=$(date +%Y-%m-%d)
tete="$HOY-$1.tar.gz"
cd /home/ezequiel/Escritorio/S.O/
> "$tete"


