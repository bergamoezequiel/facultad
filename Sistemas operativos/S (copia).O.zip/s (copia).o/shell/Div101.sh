# Mi primer shell
#Ej si se llama hola.sh 3 4 2 

z=`echo "$1%101" | bc`

if [ $z -ne 0 ] 
then
	echo "El numero pasado por parametro no es divisible por 101"
fi
