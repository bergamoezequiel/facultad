# Mi primer shell
#Ej si se llama hola.sh

if [ $1 == $2  -a  $2 == $3  ] 
then 
	echo Las tres son iguales
elif [ $1 == $2 ]
then
	echo Son iguales primera y segunda
elif [ $1 == $3 ] 
then
	echo Son iguales primera y tercera
elif [ $3 == $2 ] 
then
	echo Son iguales segunda y tercera
else
	echo Son las tres distintas
fi
