# Mi primer shell
cut -f3,5 -d":" --output-delimiter=", "  /etc/passwd |sort -k2 | cat > /home/ezequiel/Escritorio/lista4.txt



:wq
