# Mi primer shell
#Ej si se llama hola.sh 3 4 2 
function sumarTreinta 
{

parcial=`echo "$1+20" | bc`   #20 es la cantidad de segundos de retraso
final=`echo "$parcial%60" | bc`
if [ $final -lt 10 ]   #hago este if porque la funcion retorna una
			#cadena 9(ej) , y es distinto a 09
	then
	final="0$final"
fi
echo $final
}



tiempoAnt=$(date +"%T" | cut -f3 -d':')
tiempoACoincidir=$(sumarTreinta $tiempoAnt)
while [ 1 -eq 1 ]
do
	nuevoTiempo=$(date +"%T" | cut -f3 -d':')
	if [ $nuevoTiempo == $tiempoACoincidir  ]
	then
		#echo $nuevoTiempo
		#echo se entro
		tiempoACoincidir=$(sumarTreinta $tiempoACoincidir)
		if [ -f prueba.txt ]
		then 
		echo existe el archivo
		kill $$
		fi
	fi
done
