# Mi primer shell
#Ej si se llama hola.sh

if [ -d $1 ]
then
echo existe
fi

cd $1
ls -R

