# Mi primer shell
#Ej si se llama hola.sh 3 4 2 

pid=$$
#echo $$
echo "ingrese un numero: "
read prueba
intentos=1
while [ $pid -ne $prueba ]
do
	if [ $pid -lt $prueba ] 
	then
		echo "el pid es mas chico"
	else
		echo "el pid es mas grande"
	fi
	echo "ingrese un numero: "
	read prueba
	intentos=`echo "$intentos+1" | bc`
	done
echo "Le pegaste en $intentos intentos "
