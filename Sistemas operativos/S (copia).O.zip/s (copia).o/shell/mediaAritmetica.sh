# Mi primer shell
#Ej si se llama hola.sh
divisor=$#
cantPar=$#
sumaParcial=0
while [ $cantPar -ne 0 ]
do
sumaParcial=`echo "$sumaParcial+$1" | bc`
cantPar=`echo "$cantPar-1" | bc`
shift 1
done
echo "scale=40; $sumaParcial/$divisor" | bc

