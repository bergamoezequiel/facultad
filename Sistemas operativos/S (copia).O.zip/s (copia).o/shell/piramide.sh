# Mi primer shell
#Ej si se llama hola.sh

num=$( cat < /home/ezequiel/Escritorio/S.O/numero.txt )

iterador=1
while [ $num -ne 0 ] #controla los pisos de la piramide
do
clonIt=`echo "$iterador-1" | bc` #veces a sumar el string
caracter=" "$iterador

if [ $iterador -lt 10 ]
then
caracter=" 0$iterador"
fi

caracterAux=$caracter
while [ $clonIt -ne 0 ]	
do
caracter=$caracter$caracterAux	
clonIt=`echo "$clonIt-1" | bc` 
done
echo $caracter

num=`echo "$num-1" | bc`
iterador=`echo "$iterador+1" | bc`

done
