# Mi primer shell
#Ej si se llama if.sh 3 4 2 
if [ $# -lt 4 -a $1 <> '-1' ] 
then
	echo "hay menos de 4 parametros"
fi



