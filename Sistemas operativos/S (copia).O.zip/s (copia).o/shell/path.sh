# Mi primer shell
#Ej si se llama hola.sh


rutas=$PATH
rutas=$rutas:
parte=${rutas%%:*} # saca desde la primera
rutas=${rutas#*:} #  saca hasta la primera
#echo $parte



while [ -n "$rutas" ]  #mientras rutas no esta vacia
do
    parte=${rutas%%:*} # saca desde la primera
    rutas=${rutas#*:} #  saca hasta la primera
   # echo $parte
    cd $parte
    if [ -f $1  ]
    then
       echo existe
       echo $parte
       man $1
        break
    fi
   
done
