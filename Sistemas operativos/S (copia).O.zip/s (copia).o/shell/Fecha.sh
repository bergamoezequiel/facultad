# Mi primer shell
#Ej si se llama hola.sh 3 4 2 
reloj=$( date | cut -f4 -d' ' )    
dia=$( date | cut -f3 -d' ' )
mes=$( date | cut -f2 -d' ' )
anio=$( date | cut -f6 -d' ' )
echo Son las $reloj del dia: $dia
echo del mes:$mes del anio: $anio

