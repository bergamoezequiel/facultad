# Mi primer shell
#Ej si se llama hola.sh
cantidad=$#
while [ $cantidad -ne 0 ]
do
 if [ -f $1  ]
 then
     echo -------$1-------
     cat < $1

 fi
cantidad=`echo "$cantidad-1" | bc`
shift 1
done
