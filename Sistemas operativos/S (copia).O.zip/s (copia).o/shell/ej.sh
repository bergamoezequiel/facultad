var=1

while read -r linea
do
	echo "$var : $linea "
	let var=var+1
done <$1
