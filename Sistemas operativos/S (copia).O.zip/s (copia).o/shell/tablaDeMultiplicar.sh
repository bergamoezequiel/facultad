# Mi primer shell
#Ej si se llama hola.sh 3 4 2 

for i in 1 2 3 4 5 6 7 8 9 10
do
z=`echo "$1*$i" | bc`
echo "$1 X $i = $z"
done
