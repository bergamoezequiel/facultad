# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash


grep '.*/bin/bash$' /etc/passwd | sed 's/:..*:..*:..*:..*:..*:..*//' 
