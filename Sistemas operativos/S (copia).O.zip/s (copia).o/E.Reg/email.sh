# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash
#tomo como valido un email que sea cualquiercosa@cualquierCosa.com

 echo $1 | grep '^..*@..*\.com$'  
