# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash


grep  '[8-9]\.[0-9]*$\|[7]\.[6-9][0-9]*$\|[7]\.5[4-9][0-9]*$\|[7]\.53[5-9][0-9]*$\|[7]\.534[0-9]*$' /home/ezequiel/Escritorio/S.O/E.Reg/decimale.txt  
