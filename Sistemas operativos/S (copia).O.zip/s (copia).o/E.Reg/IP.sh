# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash
#si es valido lo imprimee todo  como valido X.X.X.X siendo X cualquier cantidad de numeros

 echo $1 | grep '^[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*$'  
