# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash


sed /^E/'s-^\(\S*\) \(\S*\) \(\S*\) \(\S*\) \(\S*\)-\1 \2 \3 \4 eliminado-' /home/ezequiel/Escritorio/S.O/E.Reg/lipsum.txt
 


