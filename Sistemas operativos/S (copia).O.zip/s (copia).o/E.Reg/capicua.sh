# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash

sed 'sx\([0-9]\)\([0-9]\)\([0-9]\)x\1\2\3\2\1xg' /home/ezequiel/Escritorio/S.O/capi.txt
