# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash

sed 's~\(^4...-....-....-....$\)~\1:VISA~g' /home/ezequiel/Escritorio/debito-automatico.txt | sed 's~\(^5[1-5]..-....-....-....$\)~\1:MASTERCARD~g' | sed 's~\(^3[4-7]..-....-....-...$\)~\1:American Express~g' | cat> /home/ezequiel/Escritorio/S.O/E.Reg/decimales.txt 

sed 's~\(^4...-....-....-....$\)~\1:VISA~g' /home/ezequiel/Escritorio/debito-automatico.txt | sed 's~\(^5[1-5]..-....-....-....$\)~\1:MASTERCARD~g' | sed 's~\(^3[4-7]..-....-....-...$\)~\1:American Express~g' | grep -n "^35"
