# Mi primer shell
#Ej si se llama hola.sh


#!/bin/bash


 echo $1 | grep '00:0[1-2]:[0-6][0-6]\|00:03:0[0-6]\|00:03:1[0-1]' | sed 's/.*/esMenor/' 
echo $1 | grep -v '00:0[1-2]:[0-6][0-6]\|00:03:0[0-6]\|00:03:1[0-1]' | sed 's/.*/esMayor o igual/' 
