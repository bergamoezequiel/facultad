#! /usr/bin/perl


# PARTE A
# Armar un arreglo que traduzca el numero del mes a su correspondiente nombre y mostrar el resultado
%month = ('01', 'enero', '02', 'febrero', '03', 'marzo','04', 'abril', '05', 'mayo','06', 'junio','07','julio', '08', 'agosto','09', 'septiembre','10', 'octubre','11', 'noviembre','12', 'diciembre');
foreach $i (sort keys(%month)) {
print "\n $i es $month{$i} ";
}
print "\n";

print "-------------------------------\n";
# PARTE B - acumular las ventas por mes (todas las ventas informadas corresponden al mismo año)
# imprimir un listado ordenado por mes con: "Las ventas de <nombre del mes> fueron de: <valor> pesos"
# Archivo de input en el directorio corriente con nombre: ventas2.csv y formato: fecha(aaaammdd);monto
$archivo = "/home/ezequiel/Escritorio/S.O/perl/ventas2.csv";
open (ARCHIN, "<$archivo");
@input = <ARCHIN>; #Se le asigna a las posiciones del array cada una de las lineas del archivo"

foreach $unregistro (@input) {
chomp ($unregistro);
@reg = split (";","$unregistro"); #divide la linea en fecha y monto y los pone en un array en la posicion 0 y 1 respectivamente 

$mes = substr($reg[0],4,2); #devuelve de la fecha aaaammdd (posicion 0 del array @reg) el mes  
$monto = $reg[1];
$ventas{$mes} = $ventas{$mes} + $monto; # por usar corchetes lo entiende como un hash 
}
close(ARCHIN);
foreach $i ( sort keys %ventas) {
printf "Las ventas de $month{$i} fueron de $ventas{$i} pesos\n";
}
