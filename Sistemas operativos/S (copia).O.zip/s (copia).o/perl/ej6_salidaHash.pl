#! /usr/bin/perl

%dias=("lunes",L,"martes",M,"miercoles",X,"jueves",J,"Viernes",V,"sabado",S,"Domingo",D);
foreach $clave (keys(%dias)){
	print "$clave=$dias{$clave}\n";

}
print "\n"
