#! /usr/bin/perl
print "ingrese un algo: \n";
$impu = <STDIN> ;
print $impu;
