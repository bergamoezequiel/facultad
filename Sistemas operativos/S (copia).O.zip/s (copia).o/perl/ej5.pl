#! /usr/bin/perl
@vector=(21,23,1,45,4,22,12,2,3,77);
$longArray=@vector;
$sumatoria=0;
foreach $valor (@vector){
$sumatoria=$sumatoria + $valor;	
}
$promedio=$sumatoria/$longArray;
print "el valor promedio es: $promedio \n";

$cantidadDeMayores=0;
foreach $valor (@vector){
	if ($valor>$promedio){
		push (@vectorMayores,$valor);
		$cantidadDeMayores++;
	}	
}
print "La cantidad de mayores al promedio es: $cantidadDeMayores \n";
print "los valores son: ";
foreach $valor (@vectorMayores){
print "$valor ";
}
print "\n"
