#! /usr/bin/perl
@mezcla=("hola", 23, "adios", 31.234);
foreach $valorDeArray(@mezcla){

print "$valorDeArray\n"
}

