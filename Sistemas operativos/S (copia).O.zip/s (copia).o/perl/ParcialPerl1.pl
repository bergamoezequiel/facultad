#! /usr/bin/perl
#Parámetro 1: ubicación del campo artículo
#Parámetro 2: ubicación del campo cantidad
#Parámetro 3: Nombre del archivo de Input
#Parámetro 4: Nombre del archivo de Output
$cp = $#ARGV + 1;
$cp == 4 || die "\nCantidad de parametros incorrecta\n";
$ubicacionDeArticulo=$ARGV[0];
$ubicacionDeCantidad=$ARGV[1];
$input=$ARGV[2];
$output=$ARGV[3];

-e $input || die "\nNo existe el archivo de input\n"; 

open (ARCHIN, "<$input"); #abre el archivo para lectura
open (ARCHOUT1, ">$output");#abre el archivo para escritura, lo crea sino existe

# obtencion de cantidad de campos en el registro cantidad de registros

@AInput = <ARCHIN>;
$linea=$AInput[0];
@data=split(";",$linea);
$cant=@data;
if(($ubicacionDeArticulo <1 || $ubicacionDeArticulo>$cant) || ($ubicacionDeCantidad <1 || $ubicacionDeCantidad>$cant)){

	print "parametros de ubicaciones invalidas\n";
	exit;
}
if ($ubicacionDeArticulo == $ubicacionDeCantidad){
	print "ubicaciones invalidas: misma ubicacion para Articulo y Cantidad\n";
	exit;
}

foreach $linea (@AInput){
@data=split(";",$linea);
$prod=$data[$ubicacionDeArticulo-1];
$cant=$data[$ubicacionDeCantidad-1];
$productos{$prod}=$productos{$prod} + $cant;
}
foreach $producto (sort keys %productos){
	$prodParaArch=$productos{$producto};
	print  ARCHOUT1 "$producto,$prodParaArch\n";
}
   
