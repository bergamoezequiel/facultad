#! /usr/bin/perl
#Parámetro 1: ubicación del campo artículo
#Parámetro 2: ubicación del campo cantidad
#Parámetro 3: Nombre del archivo de Input
#Parámetro 4: Nombre del archivo de Output
#corregir las rutas .. Localidades.tab no estan en el escritorio

$cp = $#ARGV + 1;
$cp == 1 || die "\nCantidad de parametros incorrecta\n";
$opcion=$ARGV[0];

if($opcion eq "-f" ){
	&procesar;	
}
elsif($opcion eq "-s" ){
while (1){
	&procesar;
	sleep 3;
}	
}
else{
print "parametro incorrecto\n";
}


sub procesar{
opendir (DIR,"."); #asi abre el directorio actual
@archivos = readdir (DIR);
closedir (DIR);
foreach $f (@archivos) {
	if ($f =~ /^*.dat$/ ){
		push(@archivosAProcesar,$f);
}
}

foreach $val (@archivosAProcesar){
	print "se valida $val\n";
	($codP,$resto)=split("-",$val);
	$codL = substr($resto,0,-4);#le corta el .dat del final
	$ABuscar=$codP.";".$codL;

#se fija si lo encuentra en Localidades.tab
	$rutaLocalidades="/home/ezequiel/Escritorio/Localidades.tab";

	open (TAB, "<$rutaLocalidades");	
	@archTab=<TAB>;
	close(TAB);
	$codValido="No";
	foreach $lineaTab (@archTab){
		chomp($lineaTab);
		if ($lineaTab eq $ABuscar){
			$codValido="Si";
			last;		
		}
	}

	if ($CodValido="Si"){
		open(ARCHDAT,$val);
		@regs=<ARCHDAT>;
		close(ARCHDAT);
		foreach $reg (@regs){
			@datos=split(";",$reg);
		$acumulador{$codP}=$acumulador{$codP}+$datos[1]+$datos[3];
		}

	}
	$fecha=localtime;
	$archAGrabar="$fecha;$codP;$acumulador{$codP}\n";
	$salida="/home/ezequiel/Escritorio/salida.txt";
	open (SAL,">>$salida");
	print SAL $archAGrabar;
}
foreach $prov (keys %acumulador){
	print "$prov =";
	$val=$acumulador{$prov};
	print "$val\n";	
}
}
