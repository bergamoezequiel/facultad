#! /usr/bin/perl

#Ej. 2. Idem ejercicio anterior pero agregando las siguientes condiciones:
#• Si la longitud del registro es mayor a 80, grabar solo el resto del registro en otro archivo (pasado como parametro 3)
#• Si la longitud del registro en cero, no grabar ninguna salida
#• El formato de la fecha debe ser: d/m/aaaa
# Validar que el archivo de input sea de lectura

#PARAMETROS ----->/home/ezequiel/Escritorio/S.O/perl/inputParaC.txt /home/ezequiel/Escritorio/S.O/perl/outputParaC.txt /home/ezequiel/Escritorio/S.O/perl/restoOutputC.txt


$cp = $#ARGV + 1;
$cp == 3 || die "Cantidad de parametros incorrecta\n";
$archi = $ARGV[0];
$arch1 = $ARGV[1];
$arch2 = $ARGV[2];
if (!-r $archi) {
print STDERR ("Archivo de input no es de lectura\n");
exit;
}
open (ARCHIN, "<$archi");
open (AROUT1, ">$arch1");
open (AROUT2, ">$arch2");

foreach $unregistro (<ARCHIN>) {
chomp ($unregistro);
$campo80 = substr($unregistro,0,80);
$campo_resto = substr($unregistro,81);
$l= length($campo80);
if ($l == 0) {
next;
}
$campo2 = getlogin;
($s,$m,$h,$dia,$mes,$anio) = localtime;
$anio += 1900;
$mes++;
$campo3 = "$dia/$mes/$anio";
print AROUT1 "$campo80;$campo2;$campo3\n";
if (length($campo_resto)) {
print AROUT2 "$campo_resto\n";
}
}
close(AROUT1,AROUT2);
