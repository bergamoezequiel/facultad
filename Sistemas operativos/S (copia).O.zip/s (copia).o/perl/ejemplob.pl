#! /usr/bin/perl


#---- PARTE A: leer primer parametro y validar que exista el directorio
$directorio = $ARGV[0];
print "el nombre del directorio donde se encuentran los archivos es:
$directorio \n";
if (!-d $directorio) {print "directorio NO encontrado\n"; exit; }

#---- PARET B: leer el directorio y listar SOLO los nombres de los archivos que empiecen con "venta" (no necesariamente que empiecen , hventa.mp3 lo toma)
# USO opendir, readdir, closedir
opendir (DIR,$directorio);#Devuelve verdadero si puede abrir el directorio
@archivos = readdir (DIR); #gruarda en el array los nombres de archivos y directorios de todo lo que hay en DIR
closedir (DIR);
foreach $f (@archivos) {
if ($f =~ "venta*"){
print " nombre del archivo de venta: $f \n";
}
}

#---- PARTE C: leer el directorio y listar path completo y nombre de los archivos que empiecen con "venta"
# USO del operador diamante: <>
@archivos_de_ventas = <$directorio/venta*>;
foreach $f (@archivos_de_ventas) {
print " path completo y nombre del archivo de venta: $f \n";
}
