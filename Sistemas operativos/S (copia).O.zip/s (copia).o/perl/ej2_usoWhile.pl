#! /usr/bin/perl
print "---PRIMEROS DIEZ NUMEROS----\n";
$comienzo=1;
while($comienzo <= 10){
print $comienzo++;
print "\n"
}

