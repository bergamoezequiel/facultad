#! /usr/bin/perl
@vectorA=(21,23,1,45,4,22,12,2,3,77);
@vectorB=(11,43,9,5,14,32,112,21,13,37);
for ($i=0;$i<10;$i++){

@vectorC[$i]=@vectorA[$i]+@vectorB[$i];
}

foreach $elemento (@vectorC){
	print "$elemento\n"
}
