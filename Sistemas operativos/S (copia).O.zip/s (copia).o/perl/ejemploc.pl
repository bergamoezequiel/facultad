#! /usr/bin/perl

#!/usr/local/bin/perl
#Ej. 1.Generar un archivo (segundo parametro) a partir de otro (primer parametro) que cumpla las siguientes condiciones:
# campo 1: registro de input HASTA 80 caracteres: si el registro de input tiene mas, truncar en 80 caracteres
# campo 2: usuario, sin formato ni longitud especificado
# campo 3: fecha, sin formato ni longitud especificado
# separador de campos: ; (carácter punto y coma)
# Validar que el archivo de input exista

#PARAMETROS ----->/home/ezequiel/Escritorio/S.O/perl/inputParaC.txt /home/ezequiel/Escritorio/S.O/perl/outputParaC.txt 

@ARGV == 2 || die "Cantidad de argumentos incorrecta\n";
($archin, $arch1) = @ARGV;
-e $archin || die "El Archivo de input no existe\n";
open (ARCHIN, "<$archin"); #abre el archivo para lectura
open (ARCHOUT1, ">$arch1");#abre el archivo para escritura, lo crea sino existe
@input = <ARCHIN>;
foreach $unregistro (@input) {
chomp ($unregistro);
$campo80 = substr($unregistro,0,80);
$campo2 = getlogin;
$campo3 = localtime;
$salida1 = join(";",($campo80,$campo2,$campo3)); 
print ARCHOUT1 "$salida1\n";
}
close(ARCHIN);
close(ARCHOUT1);
