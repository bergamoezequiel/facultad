#! /usr/bin/perl
print "---MULTIPLICACIÓN DE DOS NUMEROS----\n";
print "ingrese el primer numero:";
$numero1=<STDIN>;
print "ingrese el segundo numero:";
$numero2=<STDIN>;
$resultado=$numero1*$numero2;
print "$resultado\n"


