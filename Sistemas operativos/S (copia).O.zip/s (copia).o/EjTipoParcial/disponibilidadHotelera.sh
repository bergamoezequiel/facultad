# Mi primer shell
#!/bin/bash
# se supone que la fecha tiene que ser la indicada, y la cantidad de estrellas y huespedes exacta
cantHuespedes=$(echo $1 | sed "s/^\([^,]*\),.*/\1/") 
estrellas=$(echo $1 | sed "s/^[^,]*,\([^,]*\)/\1/")

fecha=17/02/2013

sep='[^-]*'
grep "^$sep-$sep-$estrellas-$sep-$cantHuespedes-$fecha$" /home/ezequiel/Escritorio/disponibilidad.dat | wc -l
