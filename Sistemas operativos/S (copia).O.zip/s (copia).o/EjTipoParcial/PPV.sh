# Mi primer shell
#Ej si se llama hola.sh

#llaamar de esta forma /home/ezequiel/Escritorio/hola.sh "(00)(123456)4444" 94759 telefe
#!/bin/bash

telefono=$1
CodigoCliente=$2
Canal=$3

CodigoArea=$(echo $telefono | sed 's~^(..)(\([0-9]*\))....$~\1~')


SEP='[^;]*'
senial=$(grep "^$SEP;$SEP;$SEP;$CodigoArea;$Canal;$SEP$" /home/ezequiel/Escritorio/Signals'&'Chanels.txt | sed "s~$SEP;\($SEP\);$SEP;$CodigoArea;$Canal;$SEP~\1~")

/home/ezequiel/Escritorio/RegistrarVentaPPV.sh $CodigoCliente $senial
