# Mi primer shell
#!/bin/bash

genero=$1
sep='[^;]*'
grep "^$sep;$sep;$sep;00:[3-5][0-9]:[0-5][0-9];$sep;$sep;$genero$" /home/ezequiel/Escritorio/Lista.Musical | sed "s/$sep;$sep;\($sep\);00:[3-5][0-9]:[0-5][0-9];$sep;\($sep\);$genero$/\2-\1/"

grep "^$sep;$sep;$sep;01:[0-1][0-9]:[0-5][0-9];$sep;$sep;$genero$" /home/ezequiel/Escritorio/Lista.Musical | sed "s/$sep;$sep;\($sep\);01:[0-1][0-9]:[0-5][0-9];$sep;\($sep\);$genero$/\2-\1/"

grep "^$sep;$sep;$sep;01:20:00;$sep;$sep;$genero$" /home/ezequiel/Escritorio/Lista.Musical | sed "s/$sep;$sep;\($sep\);01:20:00;$sep;\($sep\);$genero$/\2-\1/"
