#!/bin/bash
echo la empresa registro $1 , con la senial $2	
