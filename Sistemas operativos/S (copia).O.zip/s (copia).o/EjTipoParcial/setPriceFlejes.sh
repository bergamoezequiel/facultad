#!/bin/bash

echo se ingreso EAN13:$1 , sucursal: $2 , precioFlejes $3 
