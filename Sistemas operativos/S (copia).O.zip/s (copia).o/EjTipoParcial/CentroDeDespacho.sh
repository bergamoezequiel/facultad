# Mi primer shell
#Ej si se llama hola.sh

#Tengo que calcular la fecha real (de hoy) para saber la tarea del DIA
#!/bin/bash

hoy=$(date +%d/%m/%Y)

sep='[^;]*'
grep "$sep;$sep;$sep;$sep;$sep;$1;$sep;$sep;$hoy ..:..:..;$sep" /home/ezequiel/Escritorio/despacho.txt | sed "s~$sep;\($sep\);$sep;$sep;$sep;$sep;[0-3][0-9]/[0-1][1-9]/[0-2][0-9][0-9][0-9] \($sep\);$sep;$hoy ..:..:..;$sep$~la orden es \1 y la hora es \2~"
