# Mi primer shell
#Ej si se llama hola.sh

#Tengo que calcular la fecha real (de hoy) para saber la tarea del DIA
#!/bin/bash

nomPais=$1
disciplina=$2
sep='[^;]*'

registro=$(grep "^$sep;$nomPais;$sep;$disciplina" /home/ezequiel/Escritorio/Resultados.dat)
echo $registro | sed "/S;[NS];[NS];[NS];$sep$/i\ $nomPais obtuvo una medalla de oro en $disciplina" | sed "/[SN];S;[NS];[NS];$sep$/i\ $nomPais obtuvo una medalla de plata en $disciplina" | sed "/[SN];[SN];S;[NS];$sep$/i\ $nomPais obtuvo una medalla de bronce en $disciplina" | sed "/N;N;N;[NS];$sep$/i\ $nomPais no obtuvo medalla en $disciplina"| sed "s/^$sep;$nomPais;$sep;$disciplina;$sep;[NS];[NS];[NS];[NS];$sep$//" 
