# Mi primer shell
#Ej si se llama hola.sh

#Tengo que calcular la fecha real (de hoy) para saber la tarea del DIA
#!/bin/bash

codError=$1
sep='[^;]*'

#grep "^$sep;$codError;$sep;$sep;$" /home/ezequiel/Escritorio/CLASE_DE_ERRORES.dat


sed "s/^$sep;$codError;$sep;\($sep\);$/Error_Class: \1/" /home/ezequiel/Escritorio/CLASE_DE_ERRORES.dat | sed "s/$sep;$sep;$sep;$sep;$/linea/g" |sort | sed "1s/linea/<$codError> - no Clasificado/" | grep -v 'linea'
