# Mi primer shell
#!/bin/bash

idArt=$1
precio=$2
destino=$3
sep='[^;]*'
EAN13=$( grep "^$idArt;" /home/ezequiel/Escritorio/articulos.dat | sed "s/^$sep;$sep;$sep;\($sep\);$sep;$sep$/\1/")

precioFLEJES=$(echo $2 | sed "s/^\([0-9]*\)\([0-9][0-9]\)$/\1\.\2/")

/home/ezequiel/Escritorio/setPriceFlejes.sh $EAN13 $destino $precioFLEJES
