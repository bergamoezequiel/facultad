ls /home/ezequiel/Escritorio/S.O/EjTipoParcial/input | cat > /home/ezequiel/Escritorio/temp
#linea toma el valor de los nombres de los archivos
while read -r lineaArchivos
do
	proveedor=$(echo $lineaArchivos | cut -f1 -d'.' )
	fecha=$(echo $lineaArchivos | cut -f2 -d'.' )
	echo $proveedor
	echo $fecha

#archivo toma el valor de las lineas del archivo
	while read -r archivo
	do
	nroFactura=$(echo $archivo | cut -f1 -d',')
	codProd=$(echo $archivo | cut -f2 -d',')	
	cantidad=$(echo $archivo | cut -f3 -d',')
	aGrabar=$proveedor,$nroFactura,$codProd,$cantidad
echo $aGrabar
	provValido=$(cat < /home/ezequiel/Escritorio/S.O/EjTipoParcial/tablas/provema.txt | grep "$proveedor")
	if [ "$provValido" == '' ]
	then
		echo $aGrabar | cat >> /home/ezequiel/Escritorio/S.O/EjTipoParcial/error/facturas.$fecha.err
	fi

	tipoDeProductoDelProvedor=$(echo $provValido | cut -f2 -d','  )
	producto=$(cat </home/ezequiel/Escritorio/S.O/EjTipoParcial/tablas/productos.txt| grep "^$codProd")
	tipo=$(echo $producto |cut -f2 -d',' )	
	done  </home/ezequiel/Escritorio/S.O/EjTipoParcial/input/$lineaArchivos
	
	if [ "$tipo" != "$tipoDeProductoDelProvedor" ]
	
	then
	echo $aGrabar | cat >> /home/ezequiel/Escritorio/S.O/EjTipoParcial/error/facturas.$fecha.err
	else
	echo $aGrabar | cat >> /home/ezequiel/Escritorio/S.O/EjTipoParcial/ok/facturas.$fecha.ok
	fi
done  </home/ezequiel/Escritorio/temp
