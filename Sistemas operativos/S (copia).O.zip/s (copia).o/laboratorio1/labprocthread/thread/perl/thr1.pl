#! /usr/bin/perl
#
# Atencion: perl debe haber sido compilado con threads.
# Busque una distribucion asi preparada para probar este ejemplo
#
use English;
use threads;
sub sub1 {
       print "En el thread ",threads->self->tid()," proceso $PID \n";
	      }

$thr1 = threads->create(\&sub1);
$thr2 = threads->create(\&sub1);
@r1=$thr1->join;
@r2=$thr2->join;
print "En el thread ",threads->self->tid()," proceso $$ \n";	
