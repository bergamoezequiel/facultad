#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
// gcc -o prog programa.cc    genera el ejecutable prog en la carpeta actual

int main(){
pid_t yo;
yo=getpid();
printf ("Yo soy el proceso %d\n",yo);
}
